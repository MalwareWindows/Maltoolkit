Hi! its the MalvareKit / Maltoolkit! 
The malwares folder: C:\maltoolkit\imported\malwares\

I recomedded to install C++ compiler to build malware!

goodluck!