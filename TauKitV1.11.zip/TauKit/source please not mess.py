#!/usr/bin/env python3
"""
TauKit - GDI Effects Builder
Select effects, icon and compile with PyInstaller
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import os, sys, subprocess, threading, textwrap

# ════════════════════════════════════════════════════════════
#  EFFECTS DEFINITION (name, label, category, deps, code)
# ════════════════════════════════════════════════════════════
EFFECTS = [
  # ── Scroll / Blit ───────────────────────────────────────
  {"name":"scroll","label":"BitBlt Scroll","cat":"Scroll / Blit",
   "desc":"Copies the screen in 4 directions causing chaotic scrolling",
   "deps":[],"audio":"","thread":"effect_scroll",
   "code":'''\
def effect_scroll():
    while running:
        hdc=user32.GetDC(0)
        gdi32.BitBlt(hdc,0,0,SW,SH,hdc,-30,0,SRCCOPY)
        gdi32.BitBlt(hdc,0,0,SW,SH,hdc,SW-30,0,SRCCOPY)
        gdi32.BitBlt(hdc,0,0,SW,SH,hdc,0,-30,SRCCOPY)
        gdi32.BitBlt(hdc,0,0,SW,SH,hdc,0,SH-30,SRCCOPY)
        user32.ReleaseDC(0,hdc)
'''},
  {"name":"prgbtriple_shader1","label":"PRGBTRIPLE Shader1 (numpy)","cat":"Pixel Shaders",
 "desc":"DIBSection pixel shader - adds XOR pattern (numpy accelerated)",
 "deps":["numpy"],"audio":"","thread":"effect_prgbtriple_shader1_np",
 "code":'''\
def effect_prgbtriple_shader1_np():
    import numpy as np
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = -SH  # negative = top-down DIB
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    bmi.biCompression = 0
    stride = ((SW * 3 + 3) & ~3)
    # Precompute XOR pattern as numpy array
    y_vals = np.repeat(np.arange(SH), SW).reshape(SH, SW)
    x_vals = np.tile(np.arange(SW), SH).reshape(SH, SW)
    xor_pattern = ((x_vals ^ y_vals) & 0xFF).astype(np.uint8)
    # Expand to RGB channels
    xor_rgb = np.dstack([xor_pattern, xor_pattern, xor_pattern]).ravel()
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * SH)).from_address(ppv.value))
            # Add XOR pattern to RGB channels (vectorized)
            flat[::3] = (flat[::3].astype(np.uint16) + xor_pattern.ravel()) & 0xFF
            flat[1::3] = (flat[1::3].astype(np.uint16) + xor_pattern.ravel()) & 0xFF
            flat[2::3] = (flat[2::3].astype(np.uint16) + xor_pattern.ravel()) & 0xFF
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)c
        time.sleep(0.033)
'''},
  
    {"name":"infrared_shader","label":"Infrared Shader","cat":"Pixel Shaders",
   "desc":"Infrared Shader otimizado com NumPy (rápido)",
   "deps":["numpy","math"],"audio":"","thread":"effect_infrared_shader",
   "code":'''\
def effect_infrared_shader():
    import numpy as np

    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = -SH
    bmi.biPlanes = 1
    bmi.biBitCount = 32
    bmi.biCompression = 0

    hdc = user32.GetDC(0)
    memdc = gdi32.CreateCompatibleDC(hdc)
    ppv = ctypes.c_void_p()
    bmp = gdi32.CreateDIBSection(hdc, ctypes.byref(bmi), 0, ctypes.byref(ppv), None, 0)
    gdi32.SelectObject(memdc, bmp)

    i = 0
    while running:
        gdi32.BitBlt(memdc, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)

        if ppv.value:
            # Usa NumPy para processar muito mais rápido
            data = np.ctypeslib.as_array((ctypes.c_uint8 * (SW * SH * 4)).from_address(ppv.value)).reshape((SH, SW, 4))

            y, x = np.mgrid[0:SH, 0:SW]
            j = i * 3
            fx = j * (1 + np.sin(x/16.0) + np.sin(y/8.0) + np.sin((x+y)/16.0) + np.sin(np.sqrt(x*x + y*y)/8.0))

            h = (fx / 280.0 + y / SH * 0.12) % 1.0

            r = np.clip(255 * (0.6 + 0.4 * np.sin(h * 6.28)), 0, 255).astype(np.uint8)
            g = np.clip(70 + 70 * np.sin(h * 3.14), 0, 255).astype(np.uint8)
            b = np.full_like(r, 30, dtype=np.uint8)

            data[..., 0] = b
            data[..., 1] = g
            data[..., 2] = r

        gdi32.BitBlt(hdc, 0, 0, SW, SH, memdc, 0, 0, SRCCOPY)
        i += 1
        time.sleep(0.016)

    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(memdc)
    user32.ReleaseDC(0, hdc)
'''},

  {"name":"prgbtriple_shader2","label":"PRGBTRIPLE Shader2","cat":"Pixel Shaders",
 "desc":"DIBSection pixel shader - adds i&i pattern to RGB channels (C++ port)",
 "deps":[],"audio":"","thread":"effect_prgbtriple_shader2",
 "code":'''\
def effect_prgbtriple_shader2():
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = SH
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    total_pixels = SW * SH
    # Precompute i&i values (same as i in this case, but matching C++ logic)
    val_arr = [i & i for i in range(total_pixels)]
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.POINTER(RGBTRIPLE)()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv:
            for i in range(total_pixels):
                val = val_arr[i] & 0xFF
                ppv[i].rgbtRed = (ppv[i].rgbtRed + val) & 0xFF
                ppv[i].rgbtGreen = (ppv[i].rgbtGreen + val) & 0xFF
                ppv[i].rgbtBlue = (ppv[i].rgbtBlue + val) & 0xFF
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.016)  # ~60 FPS
'''},
  {"name":"multiblit","label":"Multi-Blit","cat":"Scroll / Blit",
   "desc":"Copies the screen in 12 simultaneous offsets",
   "deps":[],"audio":"","thread":"effect_multiblit",
   "code":'''\
def effect_multiblit():
    OFFS=[(-40,0),(40,0),(0,-40),(0,40),(-25,-25),(25,-25),
          (-25,25),(25,25),(-60,0),(60,0),(0,-60),(0,60)]
    while running:
        hdc=user32.GetDC(0)
        for dx,dy in OFFS:
            gdi32.BitBlt(hdc,dx,dy,SW,SH,hdc,0,0,SRCCOPY)
        user32.ReleaseDC(0,hdc)
'''},
  {"name":"srcpaint","label":"SRCPAINT Glitch","cat":"Scroll / Blit",
   "desc":"BitBlt SRCPAINT + sinusoidal scroll",
   "deps":["math"],"audio":"","thread":"effect_srcpaint",
   "code":'''\
def effect_srcpaint():
    angle=0.0
    while running:
        hdc=user32.GetDC(0)
        gdi32.BitBlt(hdc,random.randint(1,10)%2,random.randint(1,10)%2,
                     SW,SH,hdc,random.randint(1,1000)%2,random.randint(1,1000)%2,SRCPAINT)
        dx=int(math.ceil(math.sin(angle)*10))
        dy=int(math.ceil(math.cos(angle)*10))
        gdi32.BitBlt(hdc,0,0,SW,SH,hdc,dx,dy,SRCCOPY)
        angle+=0.5
        if angle>math.pi: angle=-math.pi
        user32.ReleaseDC(0,hdc)
        time.sleep(0.01)
'''},
  {"name":"stretch","label":"StretchBlt Pulse","cat":"Scroll / Blit",
   "desc":"Stretches the screen horizontally and vertically rapidly",
   "deps":[],"audio":"","thread":"effect_stretch",
   "code":'''\
def effect_stretch():
    while running:
        desk=user32.GetDC(0)
        gdi32.StretchBlt(desk,0,-20,SW,SH+40,desk,0,0,SW,SH,SRCCOPY)
        gdi32.StretchBlt(desk,-20,0,SW+40,SH,desk,0,0,SW,SH,SRCCOPY)
        user32.ReleaseDC(0,desk)
        time.sleep(0.004)
'''},
  {"name":"stretch_chaos","label":"StretchBlt Chaos","cat":"Scroll / Blit",
   "desc":"StretchBlt H+V alternating with SRCINVERT",
   "deps":[],"audio":"","thread":"effect_stretch_chaos",
   "code":'''\
def effect_stretch_chaos():
    tog=0
    while running:
        hdc=user32.GetDC(0)
        if tog%2==0:
            gdi32.StretchBlt(hdc,-20,0,SW+40,SH,hdc,0,0,SW,SH,SRCCOPY)
            gdi32.StretchBlt(hdc,-60,0,SW+120,SH,hdc,0,0,SW,SH,SRCINVERT)
        else:
            gdi32.StretchBlt(hdc,0,-20,SW,SH+40,hdc,0,0,SW,SH,SRCCOPY)
            gdi32.StretchBlt(hdc,0,-60,SW,SH+120,hdc,0,0,SW,SH,SRCINVERT)
        tog+=1
        user32.ReleaseDC(0,hdc)
'''},
  {"name":"scanline","label":"Scanline Shift","cat":"Scroll / Blit",
   "desc":"Horizontal bands shifted with SRCINVERT",
   "deps":[],"audio":"","thread":"effect_scanline",
   "code":'''\
def effect_scanline():
    while running:
        hdc=user32.GetDC(0)
        for _ in range(random.randint(8,20)):
            y_s=random.randint(0,SH); h_s=random.randint(1,18)
            dx=random.randint(-120,120)
            gdi32.BitBlt(hdc,dx,y_s,SW,h_s,hdc,0,y_s,SRCCOPY)
            gdi32.BitBlt(hdc,-dx,y_s,SW,h_s,hdc,0,y_s,SRCINVERT)
        user32.ReleaseDC(0,hdc)
'''},
  # ── Distortion ───────────────────────────────────────────
  {"name":"shake","label":"Shake","cat":"Distortion",
   "desc":"Shakes the screen with random offset",
   "deps":[],"audio":"","thread":"effect_shake",
   "code":'''\
def effect_shake():
    while running:
        hdc=user32.GetDC(0)
        gdi32.BitBlt(hdc,random.randint(-18,18),random.randint(-18,18),SW,SH,hdc,0,0,SRCCOPY)
        user32.ReleaseDC(0,hdc)
'''},
  {"name":"hardshake","label":"Hard Shake","cat":"Distortion",
   "desc":"Extreme shaking with large offset and no pause",
   "deps":[],"audio":"","thread":"effect_hardshake",
   "code":'''\
def effect_hardshake():
    while running:
        hdc=user32.GetDC(0)
        gdi32.BitBlt(hdc,random.randint(-60,60),random.randint(-60,60),SW,SH,hdc,0,0,SRCCOPY)
        user32.ReleaseDC(0,hdc)
'''},
  {"name":"distort","label":"PlgBlt Distort","cat":"Distortion",
   "desc":"Distortion using PlgBlt (parallelogram blit)",
   "deps":[],"audio":"","thread":"effect_distort",
   "code":'''\
def effect_distort():
    class RECT(ctypes.Structure):
        _fields_=[("left",wt.LONG),("top",wt.LONG),("right",wt.LONG),("bottom",wt.LONG)]
    gdi32.PlgBlt.argtypes=[wt.HDC,ctypes.POINTER(POINT),wt.HDC,ctypes.c_int,ctypes.c_int,
                            ctypes.c_int,ctypes.c_int,wt.HBITMAP,ctypes.c_int,ctypes.c_int]
    gdi32.PlgBlt.restype=wt.BOOL
    while running:
        hdc=user32.GetDC(0)
        hdcMem=gdi32.CreateCompatibleDC(hdc)
        bm=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdcMem,bm)
        rect=RECT(); user32.GetWindowRect(user32.GetDesktopWindow(),ctypes.byref(rect))
        inc3=random.randint(0,699)
        if random.randint(0,1)==1: inc3=-700
        inc3+=1
        pts=(POINT*3)(
            POINT(rect.left-inc3,rect.top+inc3),
            POINT(rect.right-inc3,rect.top-inc3),
            POINT(rect.left+inc3,rect.bottom-inc3))
        gdi32.PlgBlt(hdcMem,pts,hdc,rect.left,rect.top,
                     rect.right-rect.left,rect.bottom-rect.top,None,0,0)
        r=random.randint(0,254); g=random.randint(0,254); b=random.randint(0,254)
        brush=gdi32.CreateSolidBrush(r|(g<<8)|(b<<16))
        gdi32.SelectObject(hdc,brush)
        gdi32.BitBlt(hdc,random.randint(0,19),random.randint(0,19),SW,SH,
                     hdcMem,random.randint(0,19),random.randint(0,19),0x00660046)
        gdi32.DeleteObject(brush); gdi32.DeleteDC(hdcMem); gdi32.DeleteObject(bm)
        user32.ReleaseDC(0,hdc); time.sleep(0.001)
'''},
  {"name":"warp","label":"Sine Warp","cat":"Distortion",
   "desc":"X and Y bands with sinusoidal displacement",
   "deps":["math","win32gui","win32ui","win32con"],"audio":"","thread":"effect_warp",
   "code":'''\
def effect_warp():
    import win32gui,win32ui,win32con
    frame=0
    while running:
        hdc_desk=win32gui.GetDC(0)
        dc_desk=win32ui.CreateDCFromHandle(hdc_desk)
        dc_mem=dc_desk.CreateCompatibleDC()
        bmp=win32ui.CreateBitmap(); bmp.CreateCompatibleBitmap(dc_desk,SW,SH)
        dc_mem.SelectObject(bmp)
        dc_mem.BitBlt((0,0),(SW,SH),dc_desk,(0,0),win32con.SRCCOPY)
        amp_x=25+int(12*math.sin(frame*0.03))
        freq=max(1,10+int(5*math.sin(frame*0.02)))
        for x in range(0,SW,freq):
            sh=int(amp_x*math.sin(x*0.03+frame*0.1))
            dc_desk.BitBlt((x,sh),(freq,SH),dc_mem,(x,0),win32con.SRCCOPY)
        amp_y=20+int(10*math.sin(frame*0.05))
        for y in range(0,SH,freq):
            sh=int(amp_y*math.sin(y*0.04+frame*0.13))
            dc_desk.BitBlt((sh,y),(SW,freq),dc_mem,(0,y),win32con.SRCCOPY)
        dc_mem.DeleteDC(); win32gui.DeleteObject(bmp.GetHandle())
        win32gui.ReleaseDC(0,hdc_desk); frame+=1
'''},
  {"name":"warppool","label":"Warp Pool (Vortex)","cat":"Distortion",
   "desc":"Vortex: concentric rings pulled to the center",
   "deps":["math","win32gui","win32ui","win32con"],"audio":"","thread":"effect_warppool",
   "code":'''\
def effect_warppool():
    import win32gui,win32ui,win32con
    frame=0
    while running:
        hdc_desk=win32gui.GetDC(0)
        dc_desk=win32ui.CreateDCFromHandle(hdc_desk)
        dc_mem=dc_desk.CreateCompatibleDC()
        bmp=win32ui.CreateBitmap(); bmp.CreateCompatibleBitmap(dc_desk,SW,SH)
        dc_mem.SelectObject(bmp)
        dc_mem.BitBlt((0,0),(SW,SH),dc_desk,(0,0),win32con.SRCCOPY)
        cx2=SW//2; cy2=SH//2; rings=20; t_val=frame*0.07
        for r in range(rings,0,-1):
            frac=r/rings; w0=int(SW*frac); h0=int(SH*frac)
            x0=int(cx2-w0//2); y0=int(cy2-h0//2)
            pull=int(8*math.sin(t_val+r*0.4))
            twist=int(math.sin(t_val*0.5+r*0.2)*w0*0.06)
            if w0>4 and h0>4:
                dc_desk.BitBlt((x0+twist,y0+pull),(w0,h0//2),dc_mem,(x0,y0),win32con.SRCCOPY)
                dc_desk.BitBlt((x0-twist,y0+h0//2+pull),(w0,h0//2),dc_mem,(x0,y0+h0//2),win32con.SRCCOPY)
        dc_mem.DeleteDC(); win32gui.DeleteObject(bmp.GetHandle())
        win32gui.ReleaseDC(0,hdc_desk); frame+=1
'''},
  {"name":"invert","label":"Invert + Sine Wave","cat":"Distortion",
   "desc":"NOTSRCCOPY + sinusoidal distortion + mirrored invert",
   "deps":["math"],"audio":"","thread":"effect_invert",
   "code":'''\
def effect_invert():
    NOTSRCCOPY=0x00330008; frame=0
    while running:
        hdc=user32.GetDC(None)
        hdcMem=gdi32.CreateCompatibleDC(hdc)
        hbm=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdcMem,hbm)
        gdi32.BitBlt(hdcMem,0,0,SW,SH,hdc,0,0,SRCCOPY)
        amp=30+int(15*math.sin(frame*0.04))
        freq=max(1,6+int(3*math.sin(frame*0.025)))
        for y in range(0,SH,freq):
            shift=int(amp*math.sin(y*0.035+frame*0.12))
            gdi32.BitBlt(hdc,shift,y,SW,freq,hdcMem,0,y,NOTSRCCOPY)
        gdi32.StretchBlt(hdc,SW-1,SH-1,-SW,-SH,hdcMem,0,0,SW,SH,NOTSRCCOPY)
        gdi32.DeleteObject(hbm); gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(None,hdc); frame+=1
'''},
  {"name":"rotate","label":"Rotate + Alpha","cat":"Distortion",
   "desc":"Smooth screen rotation with AlphaBlend ghosting",
   "deps":["math"],"audio":"","thread":"effect_rotate",
   "code":'''\
def effect_rotate():
    msimg32=ctypes.windll.msimg32
    class BLENDFUNCTION(ctypes.Structure):
        _fields_=[("BlendOp",ctypes.c_byte),("BlendFlags",ctypes.c_byte),
                  ("SourceConstantAlpha",ctypes.c_byte),("AlphaFormat",ctypes.c_byte)]
    class XFORM(ctypes.Structure):
        _fields_=[("eM11",ctypes.c_float),("eM12",ctypes.c_float),
                  ("eM21",ctypes.c_float),("eM22",ctypes.c_float),
                  ("eDx",ctypes.c_float),("eDy",ctypes.c_float)]
    GM_ADVANCED=2; gdi32.SetGraphicsMode.restype=ctypes.c_int
    cur=0.0; tgt=random.uniform(-10,10); nf=time.time()+random.uniform(0.1,0.4)
    while running:
        now=time.time()
        if now>=nf: tgt=random.uniform(-12,12); nf=now+random.uniform(0.1,0.4)
        cur+=(tgt-cur)*0.3
        hdc=user32.GetDC(None); hdcMem=gdi32.CreateCompatibleDC(hdc)
        hbm=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdcMem,hbm)
        gdi32.BitBlt(hdcMem,0,0,SW,SH,hdc,0,0,SRCCOPY)
        gdi32.SetGraphicsMode(hdc,GM_ADVANCED)
        cx2=SW/2.0; cy2=SH/2.0; rad=math.radians(cur)
        c=math.cos(rad); s=math.sin(rad)
        xf=XFORM(c,s,-s,c,cx2*(1-c)+cy2*s,cy2*(1-c)-cx2*s)
        gdi32.SetWorldTransform(hdc,ctypes.byref(xf))
        bf=BLENDFUNCTION(0,0,55,0)
        msimg32.AlphaBlend(hdc,0,0,SW,SH,hdcMem,0,0,SW,SH,bf)
        bf2=BLENDFUNCTION(0,0,200,0)
        msimg32.AlphaBlend(hdc,0,0,SW,SH,hdcMem,0,0,SW,SH,bf2)
        xf_id=XFORM(1,0,0,1,0,0)
        gdi32.SetWorldTransform(hdc,ctypes.byref(xf_id))
        gdi32.DeleteObject(hbm); gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(None,hdc); time.sleep(0.016)
'''},
  {"name":"patinvert","label":"PATINVERT Diagonal","cat":"Distortion",
   "desc":"Diagonal trail with colored PATINVERT",
   "deps":["colorsys","win32gui","win32con","win32api"],"audio":"","thread":"effect_patinvert",
   "code":'''\
def effect_patinvert():
    import colorsys,win32gui,win32con,win32api
    hue=0.0
    while running:
        desktop=win32gui.GetDesktopWindow()
        hdc=win32gui.GetWindowDC(desktop)
        rgb=colorsys.hsv_to_rgb(hue%1.0,1.0,1.0)
        brush=win32gui.CreateSolidBrush(win32api.RGB(int(rgb[0]*255),int(rgb[1]*255),int(rgb[2]*255)))
        win32gui.SelectObject(hdc,brush)
        for _ in range(64):
            win32gui.BitBlt(hdc,4,4,SW,SH,hdc,0,0,win32con.SRCCOPY)
            win32gui.BitBlt(hdc,4,4,SW,SH,hdc,0,0,win32con.PATINVERT)
        win32gui.DeleteObject(brush); hue+=0.03
        win32gui.ReleaseDC(desktop,hdc)
'''},
  # ── new: invert circles (ported from desktop_effect.py) ──
  {"name":"invert_circles","label":"Invert Circles","cat":"Distortion",
   "desc":"3 smooth PATINVERT ellipses orbiting a wandering centre",
   "deps":["math","win32gui","win32con"],"audio":"","thread":"effect_invert_circles",
   "code":'''\
def effect_invert_circles():
    import win32gui,win32con
    _PATINVERT=0x005A0049
    def _inv_circ(hdc,x,y,r):
        if r<2: return
        rgn=gdi32.CreateEllipticRgn(x-r,y-r,x+r,y+r)
        gdi32.SelectClipRgn(hdc,rgn)
        gdi32.PatBlt(hdc,x-r,y-r,r*2,r*2,_PATINVERT)
        gdi32.SelectClipRgn(hdc,0)
        gdi32.DeleteObject(rgn)
    def _new_curve():
        return {"sx":random.uniform(80,500),"sy":random.uniform(80,500),
                "speed":random.uniform(0.3,2.2),"offset":random.uniform(0,6.28),
                "radius":random.randint(60,240)}
    brush=gdi32.CreateSolidBrush(0x00FFFFFF)
    desktop=user32.GetDesktopWindow()
    curves=[_new_curve() for _ in range(3)]
    cx2=float(SW//2); cy2=float(SH//2)
    lo_x=max(301,min(SW-301,300)); lo_y=max(301,min(SH-301,300))
    tx=random.randint(300,lo_x); ty=random.randint(300,lo_y)
    nxt=time.time()+2.0; last_loop=-1; prev_c=[]
    while running:
        hdc=win32gui.GetWindowDC(desktop)
        gdi32.SelectObject(hdc,brush)
        for ox,oy,or_ in prev_c:
            _inv_circ(hdc,ox,oy,or_)
        prev_c=[]
        t2=time.time()
        if t2>=nxt:
            tx=random.randint(300,lo_x); ty=random.randint(300,lo_y); nxt=t2+2.0
        cx2+=(tx-cx2)*0.008; cy2+=(ty-cy2)*0.008
        lp=int(t2*0.25)
        if lp!=last_loop: last_loop=lp; curves=[_new_curve() for _ in range(3)]
        for c in curves:
            pulse=1.0+math.sin(t2*2.0+c["offset"])*0.3
            r=int(c["radius"]*pulse)
            x=int(cx2+math.sin(t2*c["speed"]+c["offset"])*c["sx"])
            y=int(cy2+math.cos(t2*c["speed"]*1.3+c["offset"])*c["sy"])
            _inv_circ(hdc,x,y,r); prev_c.append((x,y,r))
        win32gui.ReleaseDC(desktop,hdc)
        time.sleep(0.005)
'''},
  # ── Pixels / Color ───────────────────────────────────────
  {"name":"pixels","label":"RGB Pixel Shift","cat":"Pixels / Color",
   "desc":"Adds indices to RGB channels via DIBSection",
   "deps":[],"audio":"","thread":"effect_pixels",
   "code":'''\
def effect_pixels():
    bmi=BITMAPINFOHEADER(); bmi.biSize=ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth=SW; bmi.biHeight=SH; bmi.biPlanes=1; bmi.biBitCount=24
    RGBArr=RGBTRIPLE*(SW*SH)
    while running:
        desk=user32.GetDC(0); memdc=gdi32.CreateCompatibleDC(desk)
        ppv=ctypes.c_void_p()
        scr=gdi32.CreateDIBSection(desk,ctypes.byref(bmi),0,ctypes.byref(ppv),0,0)
        gdi32.SelectObject(memdc,scr); gdi32.BitBlt(memdc,0,0,SW,SH,desk,0,0,SRCCOPY)
        if ppv.value:
            px=RGBArr.from_address(ppv.value)
            for i in range(SW*SH):
                v=i&0xFF
                px[i].rgbtRed=(px[i].rgbtRed+v)&0xFF
                px[i].rgbtGreen=(px[i].rgbtGreen+v)&0xFF
                px[i].rgbtBlue=(px[i].rgbtBlue+v)&0xFF
        gdi32.BitBlt(desk,0,0,SW,SH,memdc,0,0,SRCCOPY)
        user32.ReleaseDC(0,desk); gdi32.DeleteDC(memdc); gdi32.DeleteObject(scr)
'''},
  {"name":"notsrccopy_strip","label":"NOTSRCCOPY Strip","cat":"Pixels / Color",
   "desc":"Inverts random columns with NOTSRCCOPY",
   "deps":[],"audio":"","thread":"effect_notsrccopy_strip",
   "code":'''\
def effect_notsrccopy_strip():
    NOTSRCCOPY=0x00330008
    while running:
        hdc=user32.GetDC(0)
        x=random.randint(0,SW-10)
        gdi32.BitBlt(hdc,x,1,10,SH,hdc,x,0,NOTSRCCOPY)
        user32.ReleaseDC(0,hdc); time.sleep(0.002)
'''},
  {"name":"rgb_melt","label":"RGB Melt","cat":"Pixels / Color",
   "desc":"Melts the screen by shifting columns (vertical BitBlt)",
   "deps":[],"audio":"","thread":"effect_rgb_melt",
   "code":'''\
def effect_rgb_melt():
    while running:
        hdc=user32.GetDC(None)
        for _ in range(8):
            rx=random.randint(0,SW-1); width=random.randint(50,300)
            offset=random.randint(20,80)
            gdi32.BitBlt(hdc,rx,offset,width,SH,hdc,rx,0,SRCCOPY)
        user32.ReleaseDC(None,hdc)
'''},
  {"name":"rgbtriple_np","label":"RGB Triple (numpy)","cat":"Pixels / Color",
   "desc":"RGB channel corruption with numpy (fast)",
   "deps":["numpy"],"audio":"","thread":"effect_rgbtriple_np",
   "code":'''\
def effect_rgbtriple_np():
    import numpy as np
    class BMI2(ctypes.Structure):
        _fields_=[("bmiHeader",BITMAPINFOHEADER)]
    bmi=BMI2(); bmi.bmiHeader.biSize=ctypes.sizeof(BITMAPINFOHEADER)
    bmi.bmiHeader.biWidth=SW; bmi.bmiHeader.biHeight=-SH
    bmi.bmiHeader.biPlanes=1; bmi.bmiHeader.biBitCount=24
    bmi.bmiHeader.biCompression=0
    stride=((SW*3+3)&~3)
    idx=np.arange(SW*SH,dtype=np.uint32)
    rows=(idx//SW).astype(np.uint32); cols=(idx%SW).astype(np.uint32)
    byte_b=(rows*stride+cols*3).astype(np.int64)
    byte_g=byte_b+1; byte_r=byte_b+2
    r_add=((idx&0xFF)&(idx&0xFF)).astype(np.uint8)
    g_add=(((idx>>8)&0xFF)&(idx&0xFF)).astype(np.uint8)
    b_add=(((idx>>16)&0xFF)&(idx&0xFF)).astype(np.uint8)
    while running:
        desk=user32.GetDC(0); deskMem=gdi32.CreateCompatibleDC(desk)
        ppv=ctypes.c_void_p()
        scr=gdi32.CreateDIBSection(desk,ctypes.byref(bmi),0,ctypes.byref(ppv),0,0)
        gdi32.SelectObject(deskMem,scr); gdi32.BitBlt(deskMem,0,0,SW,SH,desk,0,0,SRCCOPY)
        if ppv.value:
            flat=np.ctypeslib.as_array((ctypes.c_uint8*(stride*SH)).from_address(ppv.value))
            flat[byte_r]=(flat[byte_r].astype(np.uint16)+r_add).astype(np.uint8)
            flat[byte_g]=(flat[byte_g].astype(np.uint16)+g_add).astype(np.uint8)
            flat[byte_b]=(flat[byte_b].astype(np.uint16)+b_add).astype(np.uint8)
        gdi32.BitBlt(desk,0,0,SW,SH,deskMem,0,0,SRCCOPY)
        user32.ReleaseDC(0,desk); gdi32.DeleteDC(deskMem); gdi32.DeleteObject(scr)
'''},
  # ── Drawing / Shapes ─────────────────────────────────────
  {"name":"bezier","label":"PolyBezier Chaos","cat":"Drawing",
   "desc":"Random red Bézier curves on screen",
   "deps":[],"audio":"","thread":"effect_bezier",
   "code":'''\
def effect_bezier():
    while running:
        hdc=user32.GetDC(0)
        pts=(POINT*4)(POINT(random.randint(0,SW),random.randint(0,SH)),
                      POINT(random.randint(0,SW),random.randint(0,SH)),
                      POINT(random.randint(0,SW),random.randint(0,SH)),
                      POINT(random.randint(0,SW),random.randint(0,SH)))
        hpen=gdi32.CreatePen(0,5,0x00FF0000)
        gdi32.SelectObject(hdc,hpen); gdi32.PolyBezier(hdc,pts,4)
        gdi32.DeleteObject(hpen); user32.ReleaseDC(0,hdc)
'''},
  {"name":"bezier_rainbow","label":"Bezier Rainbow","cat":"Drawing",
   "desc":"Rainbow Bézier curves with AlphaBlend blur",
   "deps":["math","colorsys","win32gui","win32con","win32api"],"audio":"","thread":"effect_bezier_rainbow",
   "code":'''\
def effect_bezier_rainbow():
    import colorsys,win32gui,win32con,win32api
    msimg32=ctypes.windll.msimg32
    class BLENDFUNCTION(ctypes.Structure):
        _fields_=[("BlendOp",ctypes.c_byte),("BlendFlags",ctypes.c_byte),
                  ("SourceConstantAlpha",ctypes.c_byte),("AlphaFormat",ctypes.c_byte)]
    hue=0.0
    while running:
        hdc=win32gui.GetDC(0)
        for _ in range(random.randint(3,8)):
            hue=(hue+0.005)%1.0
            rgb=colorsys.hsv_to_rgb(hue,1.0,1.0)
            p=[(random.randint(0,SW),random.randint(0,SH)) for _ in range(4)]
            hPen=win32gui.CreatePen(win32con.PS_SOLID,random.randint(3,12),
                                     win32api.RGB(int(rgb[0]*255),int(rgb[1]*255),int(rgb[2]*255)))
            win32gui.SelectObject(hdc,hPen); win32gui.PolyBezier(hdc,p)
            win32gui.DeleteObject(hPen)
        hdc_tmp=gdi32.CreateCompatibleDC(hdc)
        hbmp_tmp=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdc_tmp,hbmp_tmp)
        gdi32.BitBlt(hdc_tmp,0,0,SW,SH,hdc,0,0,win32con.SRCCOPY)
        bf=BLENDFUNCTION(0,0,180,0)
        msimg32.AlphaBlend(hdc,2,2,SW,SH,hdc_tmp,0,0,SW,SH,bf)
        gdi32.DeleteObject(hbmp_tmp); gdi32.DeleteDC(hdc_tmp)
        win32gui.ReleaseDC(0,hdc)
'''},
  {"name":"ellipse","label":"Ellipse Bounce","cat":"Drawing",
   "desc":"Colored bouncing ellipse",
   "deps":[],"audio":"","thread":"effect_ellipse",
   "code":'''\
def effect_ellipse():
    sx=1; sy=1; inc=10; x,y=10,10
    while running:
        hdc=user32.GetDC(0)
        r=random.randint(0,254); g=random.randint(0,254); b=random.randint(0,254)
        brush=gdi32.CreateSolidBrush(r|(g<<8)|(b<<16))
        gdi32.SelectObject(hdc,brush)
        gdi32.Ellipse(hdc,x,y,x+100,y+100)
        gdi32.DeleteObject(brush); user32.ReleaseDC(0,hdc)
        x+=inc*sx; y+=inc*sy
        if y>=SH: sy=-1
        if x>=SW: sx=-1
        if y<=0:  sy=1
        if x<=0:  sx=1
        time.sleep(0.01)
'''},
  {"name":"elliptic_chaos","label":"Elliptic Chaos","cat":"Drawing",
   "desc":"Nested ellipses with NOTSRCCOPY and clipping",
   "deps":["win32gui","win32con"],"audio":"","thread":"effect_elliptic_chaos",
   "code":'''\
def effect_elliptic_chaos():
    import win32gui,win32con
    from ctypes import wintypes as _wt2
    _g=ctypes.WinDLL("gdi32")
    _g.SelectClipRgn.argtypes=[_wt2.HDC,_wt2.HRGN]; _g.SelectClipRgn.restype=ctypes.c_int
    def _ci(x,y,w,h):
        hdc=win32gui.GetDC(0)
        hrgn=win32gui.CreateEllipticRgnIndirect((int(x),int(y),int(x+w),int(y+h)))
        _g.SelectClipRgn(hdc,hrgn.handle)
        win32gui.BitBlt(hdc,int(x),int(y),int(w),int(h),hdc,int(x),int(y),win32con.NOTSRCCOPY)
        _g.SelectClipRgn(hdc,0); win32gui.DeleteObject(hrgn)
        win32gui.BitBlt(hdc,random.randint(-30,30),random.randint(-30,30),SW,SH,hdc,0,0,win32con.SRCCOPY)
        win32gui.ReleaseDC(0,hdc)
    while running:
        size=random.randint(200,1200)
        x=random.randint(-size//2,SW); y=random.randint(-size//2,SH)
        i=random.randint(50,150)
        while i<=size and running:
            _ci(x-i/2,y-i/2,i,i); i+=random.randint(60,180)
'''},
  {"name":"bouncing_ball","label":"Bouncing Ball","cat":"Drawing",
   "desc":"RGB bouncing ball with AlphaBlend ghosting",
   "deps":["math","colorsys","win32gui","win32con","win32api"],"audio":"","thread":"effect_bouncing_ball",
   "code":'''\
def effect_bouncing_ball():
    import colorsys,win32gui,win32con,win32api
    msimg32=ctypes.windll.msimg32
    class BLENDFUNCTION(ctypes.Structure):
        _fields_=[("BlendOp",ctypes.c_byte),("BlendFlags",ctypes.c_byte),
                  ("SourceConstantAlpha",ctypes.c_byte),("AlphaFormat",ctypes.c_byte)]
    bx=float(SW//2); by=float(SH//2)
    vx=random.uniform(6,14)*random.choice([-1,1]); vy=random.uniform(6,14)*random.choice([-1,1])
    br=48; hue=0.0
    while running:
        hue=(hue+0.015)%1.0
        h2=(math.sin(hue*math.tau)*0.07)%1.0
        r,g,b=colorsys.hsv_to_rgb(h2,1.0,1.0)
        hdc=user32.GetDC(None)
        hdc_tmp=gdi32.CreateCompatibleDC(hdc)
        hbmp_tmp=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdc_tmp,hbmp_tmp)
        gdi32.BitBlt(hdc_tmp,0,0,SW,SH,hdc,0,0,SRCCOPY)
        bf=BLENDFUNCTION(0,0,200,0)
        msimg32.AlphaBlend(hdc,0,0,SW,SH,hdc_tmp,0,0,SW,SH,bf)
        gdi32.DeleteObject(hbmp_tmp); gdi32.DeleteDC(hdc_tmp)
        bx+=vx; by+=vy
        if bx-br<=0: bx=float(br); vx=abs(vx)*random.uniform(0.97,1.03)
        if bx+br>=SW: bx=float(SW-br); vx=-abs(vx)*random.uniform(0.97,1.03)
        if by-br<=0: by=float(br); vy=abs(vy)*random.uniform(0.97,1.03)
        if by+br>=SH: by=float(SH-br); vy=-abs(vy)*random.uniform(0.97,1.03)
        hbrush=gdi32.CreateSolidBrush(win32api.RGB(int(r*255),int(g*255),int(b*255)))
        hpen_null=gdi32.CreatePen(win32con.PS_NULL,0,0)
        gdi32.SelectObject(hdc,hbrush); gdi32.SelectObject(hdc,hpen_null)
        gdi32.Ellipse(hdc,int(bx-br),int(by-br),int(bx+br),int(by+br))
        gdi32.DeleteObject(hbrush); gdi32.DeleteObject(hpen_null)
        user32.ReleaseDC(None,hdc)
'''},
  # ── Text ─────────────────────────────────────────────────
  {"name":"death_text","label":"Death Text","cat":"Text",
   "desc":"Random phrases in random positions and colors",
   "deps":[],"audio":"","thread":"effect_death_text",
   "code":'''\
def effect_death_text():
    PHRASES=["HELLO BROTHER KAVRU!!!","death is NEAR!",
             "this malware trash...","skid!!","r.i.p pc",
             "SALVE BRASILEIROS!!!!!!!!!","THIS IS HELLL@@@@@@@!!!!!!!!!!"]
    while running:
        text=random.choice(PHRASES)
        hdc=user32.GetWindowDC(user32.GetDesktopWindow())
        gdi32.SetTextColor(hdc,random.randint(0,254)|(random.randint(0,254)<<8)|(random.randint(0,254)<<16))
        gdi32.SetBkColor(hdc,random.randint(0,254)|(random.randint(0,254)<<8)|(random.randint(0,254)<<16))
        gdi32.TextOutW(hdc,random.randint(0,SW),random.randint(0,SH),text,len(text))
        user32.ReleaseDC(user32.GetDesktopWindow(),hdc)
        time.sleep(0.01)
'''},
  {"name":"luau","label":"Luau Bounce Text","cat":"Text",
   "desc":"'luau.exe' bouncing text with colored trail",
   "deps":[],"audio":"","thread":"effect_luau",
   "code":'''\
def effect_luau():
    FONT_SIZE=48; TEXT="luau.exe"
    COLORS=[0x0000FF,0x00FF00,0xFF0000,0x00FFFF,0xFF00FF,0xFFFF00,0xFFFFFF]
    x,y=random.randint(0,SW//2),random.randint(0,SH//2)
    vx,vy=random.choice([-14,-10,10,14]),random.choice([-12,-8,8,12])
    hfont=gdi32.CreateFontW(FONT_SIZE,0,0,0,700,0,0,0,0,0,0,0,0,"Arial")
    ci=0
    while running:
        hdc=user32.GetDC(0)
        gdi32.BitBlt(hdc,x-vx*2,y-vy*2,300,FONT_SIZE+10,hdc,x-vx,y-vy,SRCCOPY)
        gdi32.SelectObject(hdc,hfont)
        gdi32.SetTextColor(hdc,COLORS[ci%len(COLORS)])
        gdi32.SetBkMode(hdc,1)
        gdi32.TextOutW(hdc,x,y,TEXT,len(TEXT))
        user32.ReleaseDC(0,hdc)
        x+=vx; y+=vy
        if x<0 or x>SW-200: vx=-vx; ci+=1; vx=int(vx*1.05) or vx
        if y<0 or y>SH-FONT_SIZE: vy=-vy; ci+=1; vy=int(vy*1.05) or vy
        vx=max(-40,min(40,vx)); vy=max(-35,min(35,vy))
        time.sleep(0.016)
'''},
  {"name":"dvd_text","label":"DVD Texts","cat":"Text",
   "desc":"5 bouncing phrases in DVD style with trail",
   "deps":[],"audio":"","thread":"effect_dvd_text",
   "code":'''\
def effect_dvd_text():
    msimg32=ctypes.windll.msimg32
    class BLENDFUNCTION(ctypes.Structure):
        _fields_=[("BlendOp",ctypes.c_byte),("BlendFlags",ctypes.c_byte),
                  ("SourceConstantAlpha",ctypes.c_byte),("AlphaFormat",ctypes.c_byte)]
    TEXTS=["death is NEAR!","luau.exe","HELLO BROTHER KAVRU!!!","skid!!",
           "this malware trash... I DONT KNOW WHY MY CODE IS SO TRASH"]
    COLORS=[0x0000FF,0x00FF00,0xFF0000,0x00FFFF,0xFF00FF,0xFFFF00,0xFFFFFF]
    FS=52; hfont=gdi32.CreateFontW(FS,0,0,0,700,0,0,0,0,0,0,0,0,"Arial")
    balls=[{"x":random.randint(0,SW//2),"y":random.randint(0,SH//2),
            "vx":random.choice([-12,-9,9,12]),"vy":random.choice([-10,-7,7,10]),
            "text":random.choice(TEXTS),"color":random.choice(COLORS)} for _ in range(5)]
    while running:
        hdc=user32.GetDC(None)
        hdcm=gdi32.CreateCompatibleDC(hdc); hbm=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdcm,hbm); gdi32.BitBlt(hdcm,0,0,SW,SH,hdc,0,0,SRCCOPY)
        bf=BLENDFUNCTION(0,0,50,0)
        msimg32.AlphaBlend(hdc,3,3,SW,SH,hdcm,0,0,SW,SH,bf)
        gdi32.DeleteObject(hbm); gdi32.DeleteDC(hdcm)
        for b in balls:
            gdi32.SelectObject(hdc,hfont)
            gdi32.SetTextColor(hdc,b["color"]); gdi32.SetBkMode(hdc,1)
            gdi32.TextOutW(hdc,b["x"],b["y"],b["text"],len(b["text"]))
            b["x"]+=b["vx"]; b["y"]+=b["vy"]
            tw=int(len(b["text"])*FS*0.55)
            if b["x"]<0 or b["x"]>SW-tw:
                b["vx"]=-b["vx"]; b["color"]=random.choice(COLORS); b["text"]=random.choice(TEXTS)
            if b["y"]<0 or b["y"]>SH-FS:
                b["vy"]=-b["vy"]; b["color"]=random.choice(COLORS); b["text"]=random.choice(TEXTS)
        user32.ReleaseDC(None,hdc); time.sleep(0.016)
'''},
  {"name":"syscrusher_text","label":"SysCrusher Text","cat":"Text",
   "desc":"Rotating texts with various fonts",
   "deps":["math","colorsys","win32gui","win32api"],"audio":"","thread":"effect_syscrusher_text",
   "code":'''\
def effect_syscrusher_text():
    import colorsys,win32gui,win32api
    FONTS=["Impact","Arial Black","Courier New","Comic Sans MS","Times New Roman",
           "Verdana","Trebuchet MS","Consolas","Lucida Console","Tahoma"]
    class LOGFONT(ctypes.Structure):
        _fields_=[("lfHeight",ctypes.c_long),("lfWidth",ctypes.c_long),
                  ("lfEscapement",ctypes.c_long),("lfOrientation",ctypes.c_long),
                  ("lfWeight",ctypes.c_long),("lfItalic",ctypes.c_byte),
                  ("lfUnderline",ctypes.c_byte),("lfStrikeOut",ctypes.c_byte),
                  ("lfCharSet",ctypes.c_byte),("lfOutPrecision",ctypes.c_byte),
                  ("lfClipPrecision",ctypes.c_byte),("lfQuality",ctypes.c_byte),
                  ("lfPitchAndFamily",ctypes.c_byte),("lfFaceName",ctypes.c_wchar*32)]
    PHRASES=["SysCrusher.exe","death is NEAR!","luau.exe","HELLO BROTHER KAVRU!!!",
             "skid!!","r.i.p pc","SALVE BRASILEIROS!!!!!!!!!"]
    while running:
        hdc=win32gui.GetDC(0)
        for _ in range(random.randint(3,7)):
            x=random.randint(0,SW-300); y=random.randint(0,SH-80)
            sz=random.randint(14,48); ang=random.randint(-450,450)
            lf=LOGFONT(); lf.lfHeight=-sz; lf.lfWeight=random.choice([400,700,900])
            lf.lfItalic=random.randint(0,1); lf.lfEscapement=ang; lf.lfOrientation=ang
            lf.lfCharSet=0; lf.lfFaceName=random.choice(FONTS)
            hfont=gdi32.CreateFontIndirectW(ctypes.byref(lf))
            old=gdi32.SelectObject(hdc,hfont)
            color=win32api.RGB(random.randint(50,255),random.randint(50,255),random.randint(50,255))
            gdi32.SetTextColor(hdc,color); gdi32.SetBkMode(hdc,1)
            txt=random.choice(PHRASES)
            gdi32.TextOutW(hdc,x,y,txt,len(txt))
            gdi32.SelectObject(hdc,old); gdi32.DeleteObject(hfont)
        win32gui.ReleaseDC(0,hdc); time.sleep(0.05)
'''},
{"name":"prgbtriple_shader2_mult","label":"PRGBQUAD SHADER2 (pankoza)","cat":"Pixel Shaders",
 "desc":"Accurate recreation of shader2 from pankoza - adds x*y to RGB channels",
 "deps":["numpy"],"audio":"","thread":"effect_prgbtriple_shader2_mult",
 "code":'''\
def effect_prgbtriple_shader2_mult():
    import numpy as np
    w = SW
    h = SH
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = w
    bmi.biHeight = -h
    bmi.biPlanes = 1
    bmi.biBitCount = 32
    bmi.biCompression = 0
    stride = w * 4
    # Precompute x*y pattern once (vectorized, no loop)
    y_coords = np.arange(h, dtype=np.uint32).reshape(h, 1)
    x_coords = np.arange(w, dtype=np.uint32).reshape(1, w)
    xy_pattern = (x_coords * y_coords).astype(np.uint8)
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, w, h, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * h)).from_address(ppv.value))
            px = flat.reshape(h, w, 4)
            # Vectorized addition (no Python loops, no overflow warnings)
            px[:,:,0] = (px[:,:,0].astype(np.uint16) + xy_pattern).astype(np.uint8)  # B
            px[:,:,1] = (px[:,:,1].astype(np.uint16) + xy_pattern).astype(np.uint8)  # G
            px[:,:,2] = (px[:,:,2].astype(np.uint16) + xy_pattern).astype(np.uint8)  # R
        gdi32.BitBlt(desk, 0, 0, w, h, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.016)
'''},

  # ── NEW Scroll / Blit Effects ───────────────────────────────────
  {"name":"new_rolling_credits","label":"Rolling Credits","cat":"Scroll / Blit",
   "desc":"Vertical scrolling text strip effect",
   "deps":[],"audio":"","thread":"effect_new_rolling_credits",
   "code":'''\
def effect_new_rolling_credits():
    y_offset = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        gdi32.BitBlt(hdc, 0, y_offset, SW, SH, hdcMem, 0, 0, SRCCOPY)
        gdi32.BitBlt(hdc, 0, y_offset - SH, SW, SH, hdcMem, 0, 0, SRCCOPY)
        y_offset = (y_offset + 5) % SH
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.016)
'''},
  {"name":"new_horizontal_wrap","label":"Horizontal Wrap","cat":"Scroll / Blit",
   "desc":"Screen wraps horizontally like a cylinder",
   "deps":[],"audio":"","thread":"effect_new_horizontal_wrap",
   "code":'''\
def effect_new_horizontal_wrap():
    x_offset = 0
    direction = 1
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        gdi32.BitBlt(hdc, x_offset, 0, SW, SH, hdcMem, 0, 0, SRCCOPY)
        gdi32.BitBlt(hdc, x_offset - SW, 0, SW, SH, hdcMem, 0, 0, SRCCOPY)
        x_offset += direction * 8
        if abs(x_offset) > SW:
            direction *= -1
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.016)
'''},
  {"name":"new_venetian_blinds","label":"Venetian Blinds","cat":"Scroll / Blit",
   "desc":"Alternating horizontal bands shift left/right",
   "deps":[],"audio":"","thread":"effect_new_venetian_blinds",
   "code":'''\
def effect_new_venetian_blinds():
    t = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        band_height = 20
        for y in range(0, SH, band_height * 2):
            offset = int(math.sin(t + y * 0.05) * 30)
            gdi32.BitBlt(hdc, offset, y, SW, band_height, hdcMem, 0, y, SRCCOPY)
        t += 0.1
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.016)
'''},
  {"name":"new_curtain_open","label":"Curtain Open","cat":"Scroll / Blit",
   "desc":"Screen splits from center and moves outward",
   "deps":[],"audio":"","thread":"effect_new_curtain_open",
   "code":'''\
def effect_new_curtain_open():
    t = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        split = int(abs(math.sin(t)) * SW // 2)
        gdi32.BitBlt(hdc, -split, 0, SW//2, SH, hdcMem, 0, 0, SRCCOPY)
        gdi32.BitBlt(hdc, SW//2 + split, 0, SW//2, SH, hdcMem, SW//2, 0, SRCCOPY)
        t += 0.02
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.016)
'''},
  {"name":"new_waterfall","label":"Waterfall","cat":"Scroll / Blit",
   "desc":"Pixels fall downward like water",
   "deps":[],"audio":"","thread":"effect_new_waterfall",
   "code":'''\
def effect_new_waterfall():
    y_offset = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        for y in range(SH-1, 0, -1):
            gdi32.BitBlt(hdc, 0, y, SW, 1, hdcMem, 0, y-1, SRCCOPY)
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.008)
'''},

  # ── NEW Distortion Effects ──────────────────────────────────────
  {"name":"new_swirl","label":"Swirl Distortion","cat":"Distortion",
   "desc":"Screen swirls around center like a vortex",
   "deps":["math"],"audio":"","thread":"effect_new_swirl",
   "code":'''\
def effect_new_swirl():
    import math
    cx, cy = SW//2, SH//2
    angle = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        for y in range(0, SH, 4):
            for x in range(0, SW, 4):
                dx = x - cx
                dy = y - cy
                dist = math.sqrt(dx*dx + dy*dy)
                if dist > 0:
                    a = math.atan2(dy, dx) + angle * (1 - dist / max(cx, cy))
                    sx = int(cx + math.cos(a) * dist)
                    sy = int(cy + math.sin(a) * dist)
                    if 0 <= sx < SW and 0 <= sy < SH:
                        gdi32.BitBlt(hdc, x, y, 4, 4, hdcMem, sx, sy, SRCCOPY)
        angle += 0.03
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
  {"name":"new_bulge","label":"Bulge Effect","cat":"Distortion",
   "desc":"Screen bulges outward from center",
   "deps":["math"],"audio":"","thread":"effect_new_bulge",
   "code":'''\
def effect_new_bulge():
    import math
    cx, cy = SW//2, SH//2
    t = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        bulge = 1.5 + math.sin(t) * 0.3
        for y in range(0, SH, 4):
            for x in range(0, SW, 4):
                dx = (x - cx) / cx
                dy = (y - cy) / cy
                dist = math.sqrt(dx*dx + dy*dy)
                if dist > 0:
                    factor = 1 + (1 - dist) * (bulge - 1)
                    sx = int(cx + dx * factor * cx)
                    sy = int(cy + dy * factor * cy)
                    if 0 <= sx < SW and 0 <= sy < SH:
                        gdi32.BitBlt(hdc, x, y, 4, 4, hdcMem, sx, sy, SRCCOPY)
        t += 0.05
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
  {"name":"new_twist","label":"Twist Effect","cat":"Distortion",
   "desc":"Screen twists like a screw",
   "deps":["math"],"audio":"","thread":"effect_new_twist",
   "code":'''\
def effect_new_twist():
    import math
    t = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        for y in range(0, SH, 4):
            offset = int(math.sin(y * 0.02 + t) * 50)
            gdi32.BitBlt(hdc, offset, y, SW, 4, hdcMem, 0, y, SRCCOPY)
            gdi32.BitBlt(hdc, -offset//2, y+2, SW, 2, hdcMem, 0, y+2, SRCINVERT)
        t += 0.08
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.016)
'''},
  {"name":"new_pinwheel","label":"Pinwheel","cat":"Distortion",
   "desc":"Pinwheel spinning distortion",
   "deps":["math"],"audio":"","thread":"effect_new_pinwheel",
   "code":'''\
def effect_new_pinwheel():
    import math
    cx, cy = SW//2, SH//2
    angle = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        for y in range(0, SH, 5):
            for x in range(0, SW, 5):
                dx = x - cx
                dy = y - cy
                a = math.atan2(dy, dx) + angle
                r = math.sqrt(dx*dx + dy*dy)
                sx = int(cx + math.cos(a) * r)
                sy = int(cy + math.sin(a) * r)
                if 0 <= sx < SW and 0 <= sy < SH:
                    gdi32.BitBlt(hdc, x, y, 5, 5, hdcMem, sx, sy, SRCCOPY)
        angle += 0.02
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
  {"name":"new_wavepool","label":"Wave Pool","cat":"Distortion",
   "desc":"Concentric wave rings",
   "deps":["math"],"audio":"","thread":"effect_new_wavepool",
   "code":'''\
def effect_new_wavepool():
    import math
    cx, cy = SW//2, SH//2
    t = 0
    while running:
        hdc = user32.GetDC(0)
        hdcMem = gdi32.CreateCompatibleDC(hdc)
        hbm = gdi32.CreateCompatibleBitmap(hdc, SW, SH)
        gdi32.SelectObject(hdcMem, hbm)
        gdi32.BitBlt(hdcMem, 0, 0, SW, SH, hdc, 0, 0, SRCCOPY)
        for r in range(0, max(SW, SH)//2, 15):
            wave = int(math.sin(r * 0.05 + t) * 20)
            gdi32.BitBlt(hdc, cx - r + wave, cy - r, r*2, r*2, hdcMem, cx - r, cy - r, SRCCOPY)
            gdi32.BitBlt(hdc, cx - r - wave, cy - r, r*2, r*2, hdcMem, cx - r, cy - r, SRCINVERT)
        t += 0.05
        gdi32.DeleteObject(hbm)
        gdi32.DeleteDC(hdcMem)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},

  # ── NEW Pixels / Color Effects ──────────────────────────────────
  {"name":"new_solarize","label":"Solarize","cat":"Pixels / Color",
   "desc":"Solarization effect (inverts bright pixels)",
   "deps":["numpy"],"audio":"","thread":"effect_new_solarize",
   "code":'''\
def effect_new_solarize():
    import numpy as np
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = SH
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    stride = (SW * 3 + 3) & ~3
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * SH)).from_address(ppv.value))
            px = flat.reshape(SH, stride)[:,:SW*3].reshape(SH, SW, 3)
            # Solarize: if value > 127, invert it
            mask = px > 127
            px[mask] = 255 - px[mask]
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.033)
'''},
  {"name":"new_posterize","label":"Posterize","cat":"Pixels / Color",
   "desc":"Reduces color depth to 4 bits per channel",
   "deps":["numpy"],"audio":"","thread":"effect_new_posterize",
   "code":'''\
def effect_new_posterize():
    import numpy as np
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = SH
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    stride = (SW * 3 + 3) & ~3
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * SH)).from_address(ppv.value))
            px = flat.reshape(SH, stride)[:,:SW*3].reshape(SH, SW, 3)
            # Reduce to 4 bits per channel (0, 17, 34, ... 255)
            px = (px // 17) * 17
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.033)
'''},
  {"name":"new_thermal","label":"Thermal Vision","cat":"Pixels / Color",
   "desc":"Thermal camera color mapping",
   "deps":["numpy"],"audio":"","thread":"effect_new_thermal",
   "code":'''\
def effect_new_thermal():
    import numpy as np
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = SH
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    stride = (SW * 3 + 3) & ~3
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * SH)).from_address(ppv.value))
            px = flat.reshape(SH, stride)[:,:SW*3].reshape(SH, SW, 3)
            brightness = (px[:,:,0].astype(np.uint16) + px[:,:,1] + px[:,:,2]) // 3
            # Thermal map: cold=blue, warm=red
            px[:,:,0] = np.clip(brightness * 2, 0, 255).astype(np.uint8)      # B
            px[:,:,1] = np.clip(255 - abs(brightness - 127) * 2, 0, 255).astype(np.uint8)  # G
            px[:,:,2] = np.clip(brightness * 2 - 255, 0, 255).astype(np.uint8) # R
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.033)
'''},
  {"name":"new_negate_rgb","label":"Negate RGB","cat":"Pixels / Color",
   "desc":"Inverts each color channel independently with offset",
   "deps":["numpy"],"audio":"","thread":"effect_new_negate_rgb",
   "code":'''\
def effect_new_negate_rgb():
    import numpy as np
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = SH
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    stride = (SW * 3 + 3) & ~3
    t = 0
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * SH)).from_address(ppv.value))
            px = flat.reshape(SH, stride)[:,:SW*3].reshape(SH, SW, 3)
            offset = int(math.sin(t) * 50)
            px[:,:,0] = 255 - (px[:,:,0] + offset) & 0xFF  # B
            px[:,:,1] = 255 - (px[:,:,1] + offset//2) & 0xFF  # G
            px[:,:,2] = 255 - px[:,:,2]  # R
        t += 0.05
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.033)
'''},
  {"name":"new_color_cycle","label":"Color Cycle","cat":"Pixels / Color",
   "desc":"Shifts hue through RGB rotation",
   "deps":["numpy"],"audio":"","thread":"effect_new_color_cycle",
   "code":'''\
def effect_new_color_cycle():
    import numpy as np
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = SW
    bmi.biHeight = SH
    bmi.biPlanes = 1
    bmi.biBitCount = 24
    stride = (SW * 3 + 3) & ~3
    shift = 0
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        gdi32.BitBlt(deskMem, 0, 0, SW, SH, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * SH)).from_address(ppv.value))
            px = flat.reshape(SH, stride)[:,:SW*3].reshape(SH, SW, 3)
            # RGB -> GBR -> BRG cycle
            if shift == 0:
                pass  # RGB
            elif shift == 1:
                px = px[:,:,[1,2,0]]  # GBR
            elif shift == 2:
                px = px[:,:,[2,0,1]]  # BRG
        gdi32.BitBlt(desk, 0, 0, SW, SH, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        shift = (shift + 1) % 3
        time.sleep(0.5)
'''},

  # ── NEW Drawing Effects ────────────────────────────────────────
  {"name":"new_fireworks","label":"Fireworks","cat":"Drawing",
   "desc":"Random colored explosions",
   "deps":[],"audio":"","thread":"effect_new_fireworks",
   "code":'''\
def effect_new_fireworks():
    particles = []
    while running:
        hdc = user32.GetDC(0)
        if random.random() < 0.1 and len(particles) < 20:
            particles.append({
                'x': random.randint(0, SW),
                'y': random.randint(0, SH),
                'vx': random.uniform(-5, 5),
                'vy': random.uniform(-5, 5),
                'life': 30,
                'color': random.randint(0, 0xFFFFFF)
            })
        for p in particles[:]:
            brush = gdi32.CreateSolidBrush(p['color'])
            gdi32.SelectObject(hdc, brush)
            gdi32.Ellipse(hdc, int(p['x']-3), int(p['y']-3), int(p['x']+3), int(p['y']+3))
            gdi32.DeleteObject(brush)
            p['x'] += p['vx']
            p['y'] += p['vy']
            p['life'] -= 1
            if p['life'] <= 0 or p['x'] < 0 or p['x'] > SW or p['y'] < 0 or p['y'] > SH:
                particles.remove(p)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
 
  {"name":"new_rainbow_grid","label":"Rainbow Grid","cat":"Drawing",
   "desc":"Draws animated rainbow grid lines",
   "deps":["math"],"audio":"","thread":"effect_new_rainbow_grid",
   "code":'''\
def effect_new_rainbow_grid():
    import math
    t = 0
    while running:
        hdc = user32.GetDC(0)
        for i in range(0, max(SW, SH), 40):
            hue = (t + i * 0.01) % 1.0
            r = int((math.sin(hue * math.pi * 2) + 1) * 127)
            g = int((math.sin(hue * math.pi * 2 + 2.094) + 1) * 127)
            b = int((math.sin(hue * math.pi * 2 + 4.188) + 1) * 127)
            pen = gdi32.CreatePen(0, 2, r | (g << 8) | (b << 16))
            gdi32.SelectObject(hdc, pen)
            gdi32.MoveToEx(hdc, i % SW, 0, None)
            gdi32.LineTo(hdc, i % SW, SH)
            gdi32.MoveToEx(hdc, 0, i % SH, None)
            gdi32.LineTo(hdc, SW, i % SH)
            gdi32.DeleteObject(pen)
        t += 0.02
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
  {"name":"new_confetti","label":"Confetti","cat":"Drawing",
   "desc":"Falling confetti particles",
   "deps":[],"audio":"","thread":"effect_new_confetti",
   "code":'''\
def effect_new_confetti():
    particles = []
    while running:
        hdc = user32.GetDC(0)
        if random.random() < 0.2 and len(particles) < 100:
            particles.append({
                'x': random.randint(0, SW),
                'y': 0,
                'size': random.randint(3, 10),
                'color': random.randint(0, 0xFFFFFF),
                'speed': random.uniform(2, 8)
            })
        for p in particles[:]:
            brush = gdi32.CreateSolidBrush(p['color'])
            gdi32.SelectObject(hdc, brush)
            gdi32.Rectangle(hdc, p['x'], int(p['y']), p['x']+p['size'], int(p['y'])+p['size'])
            gdi32.DeleteObject(brush)
            p['y'] += p['speed']
            if p['y'] > SH:
                particles.remove(p)
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
  {"name":"new_target","label":"Target Reticle","cat":"Drawing",
   "desc":"Draws animated target reticles",
   "deps":["math"],"audio":"","thread":"effect_new_target",
   "code":'''\
def effect_new_target():
    import math
    t = 0
    while running:
        hdc = user32.GetDC(0)
        for _ in range(5):
            x = random.randint(0, SW)
            y = random.randint(0, SH)
            radius = int(20 + math.sin(t) * 10)
            for r in range(radius, 0, -5):
                color = (r * 50) % 0xFFFFFF
                brush = gdi32.CreateSolidBrush(color)
                gdi32.SelectObject(hdc, brush)
                gdi32.Ellipse(hdc, x-r, y-r, x+r, y+r)
                gdi32.DeleteObject(brush)
        t += 0.05
        user32.ReleaseDC(0, hdc)
        time.sleep(0.05)
'''},

 
  {"name":"new_marquee","label":"Marquee Text","cat":"Text",
   "desc":"Scrolling text across screen",
   "deps":[],"audio":"","thread":"effect_new_marquee",
   "code":'''\
def effect_new_marquee():
    text = "SKID!!!!!!!!1 "
    x_pos = SW
    while running:
        hdc = user32.GetDC(0)
        gdi32.SetTextColor(hdc, random.randint(0, 0xFFFFFF))
        gdi32.SetBkMode(hdc, 1)
        gdi32.TextOutW(hdc, x_pos, SH//2, text, len(text))
        x_pos -= 5
        if x_pos < -len(text)*10:
            x_pos = SW
        user32.ReleaseDC(0, hdc)
        time.sleep(0.033)
'''},
 
 
{"name":"prgbtriple_shader3","label":"PRGBQUAD Silver","cat":"Pixel Shaders",
 "desc":"32-bit DIB section with (x & y) * Hue(239) pattern",
 "deps":["numpy"],"audio":"","thread":"effect_prgbtriple_shader3",
 "code":'''\
def effect_prgbtriple_shader3():
    import numpy as np
    w = SW
    h = SH
    bmi = BITMAPINFOHEADER()
    bmi.biSize = ctypes.sizeof(BITMAPINFOHEADER)
    bmi.biWidth = w
    bmi.biHeight = -h
    bmi.biPlanes = 1
    bmi.biBitCount = 32
    bmi.biCompression = 0
    stride = w * 4
    # Hue(239) - RGB values for hue 239 degrees
    # Convert hue 239 to RGB (239/360 = 0.6639)
    # Hue 239 is blue-purple range: R ~ 0, G ~ 51, B ~ 255
    hue_r = 0
    hue_g = 51
    hue_b = 255
    # Precompute x & y pattern scaled by Hue(239)
    # Create meshgrid of x and y coordinates
    y_coords = np.arange(h, dtype=np.uint32).reshape(h, 1)
    x_coords = np.arange(w, dtype=np.uint32).reshape(1, w)
    pattern = (x_coords & y_coords).astype(np.uint32)
    # Multiply each channel by the pattern
    r_vals = ((pattern * hue_r) & 0xFF).astype(np.uint8)
    g_vals = ((pattern * hue_g) & 0xFF).astype(np.uint8)
    b_vals = ((pattern * hue_b) & 0xFF).astype(np.uint8)
    while running:
        desk = user32.GetDC(0)
        deskMem = gdi32.CreateCompatibleDC(desk)
        ppv = ctypes.c_void_p()
        scr = gdi32.CreateDIBSection(desk, ctypes.byref(bmi), 0, ctypes.byref(ppv), 0, 0)
        gdi32.SelectObject(deskMem, scr)
        # Capture screen
        gdi32.BitBlt(deskMem, 0, 0, w, h, desk, 0, 0, SRCCOPY)
        if ppv.value:
            flat = np.ctypeslib.as_array((ctypes.c_uint8 * (stride * h)).from_address(ppv.value))
            px = flat.reshape(h, w, 4)
            # Apply (x & y) * Hue(239) pattern to RGB channels
            px[:,:,0] = b_vals  # B channel
            px[:,:,1] = g_vals  # G channel
            px[:,:,2] = r_vals  # R channel
            # Alpha channel stays 0
        # Blit back to screen
        gdi32.BitBlt(desk, 0, 0, w, h, deskMem, 0, 0, SRCCOPY)
        user32.ReleaseDC(0, desk)
        gdi32.DeleteDC(deskMem)
        gdi32.DeleteObject(scr)
        time.sleep(0.016)
'''},
  # ── Icons ────────────────────────────────────────────────
  {"name":"shell_icons","label":"Shell Icons Spam","cat":"Icons",
   "desc":"Shell32 icons in random sizes and positions",
   "deps":["win32gui"],"audio":"","thread":"effect_shell_icons",
   "code":'''\
def effect_shell_icons():
    import win32gui
    msimg32=ctypes.windll.msimg32
    class BLENDFUNCTION(ctypes.Structure):
        _fields_=[("BlendOp",ctypes.c_byte),("BlendFlags",ctypes.c_byte),
                  ("SourceConstantAlpha",ctypes.c_byte),("AlphaFormat",ctypes.c_byte)]
    DI_NORMAL=0x0003; shell32="C:\\\\Windows\\\\System32\\\\shell32.dll"
    icons=[]
    for idx in range(0,320,3):
        try:
            large,small=win32gui.ExtractIconEx(shell32,idx,1)
            if large: icons.append(large[0])
            if small: win32gui.DestroyIcon(small[0])
        except: pass
    if not icons: return
    while running:
        hdc=win32gui.GetDC(0)
        hdcm=gdi32.CreateCompatibleDC(hdc); hbm=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdcm,hbm); gdi32.BitBlt(hdcm,0,0,SW,SH,hdc,0,0,SRCCOPY)
        bf=BLENDFUNCTION(0,0,40,0)
        for dx,dy in [(-3,0),(3,0),(0,-3),(0,3),(-2,-2),(2,-2),(-2,2),(2,2)]:
            msimg32.AlphaBlend(hdc,dx,dy,SW,SH,hdcm,0,0,SW,SH,bf)
        gdi32.DeleteObject(hbm); gdi32.DeleteDC(hdcm)
        for _ in range(12):
            icon=random.choice(icons)
            sw2=random.choice([24,32,48,64,96,128,160]); sh2=random.choice([24,32,48,64,96,128,160])
            x=random.randint(-sw2,SW); y=random.randint(-sh2,SH)
            win32gui.DrawIconEx(hdc,x,y,icon,sw2,sh2,0,0,DI_NORMAL)
        win32gui.ReleaseDC(0,hdc); time.sleep(0.033)
'''},
  {"name":"donut","label":"Donut 3D (Icons)","cat":"Icons",
   "desc":"3D Donut made of rotating shell32 icons",
   "deps":["math","win32gui"],"audio":"","thread":"effect_donut",
   "code":'''\
def effect_donut():
    import win32gui,math as _m
    msimg32=ctypes.windll.msimg32
    class BLENDFUNCTION(ctypes.Structure):
        _fields_=[("BlendOp",ctypes.c_byte),("BlendFlags",ctypes.c_byte),
                  ("SourceConstantAlpha",ctypes.c_byte),("AlphaFormat",ctypes.c_byte)]
    DI_NORMAL=0x0003; shell32="C:\\\\Windows\\\\System32\\\\shell32.dll"
    icons=[]
    for idx in range(0,200,10):
        try:
            large,small=win32gui.ExtractIconEx(shell32,idx,1)
            if large: icons.append(large[0])
            if small: win32gui.DestroyIcon(small[0])
        except: pass
    if not icons: return
    NM=18; Nm=10; RM=200; Rm=70; IS=24
    cx=SW//2; cy=SH//2; vx=random.choice([-5,5]); vy=random.choice([-4,4])
    aa=0.0; ab=0.0
    while running:
        hdc=user32.GetDC(None)
        hdcm=gdi32.CreateCompatibleDC(hdc); hbm=gdi32.CreateCompatibleBitmap(hdc,SW,SH)
        gdi32.SelectObject(hdcm,hbm); gdi32.BitBlt(hdcm,0,0,SW,SH,hdc,0,0,SRCCOPY)
        bf=BLENDFUNCTION(0,0,45,0)
        msimg32.AlphaBlend(hdc,2,2,SW,SH,hdcm,0,0,SW,SH,bf)
        gdi32.DeleteObject(hbm); gdi32.DeleteDC(hdcm)
        ca=_m.cos(aa); sa=_m.sin(aa); cb=_m.cos(ab); sb=_m.sin(ab)
        ioff=random.randint(0,len(icons)-1)
        for i in range(NM):
            t=2*_m.pi*i/NM; ct=_m.cos(t); st=_m.sin(t)
            for j in range(Nm):
                p=2*_m.pi*j/Nm; cp=_m.cos(p); sp=_m.sin(p)
                ox=(RM+Rm*cp)*ct; oy=(RM+Rm*cp)*st; oz=Rm*sp
                rx=ox*ca-oy*sa; ry=ox*sa+oy*ca
                rz=oz*cb-ry*sb; ry2=oz*sb+ry*cb
                sc=600/(600+rz)
                sx2=int(cx+rx*sc); sy2=int(cy+ry2*sc)
                icon=icons[(i*Nm+j+ioff)%len(icons)]
                sz=max(8,int(IS*sc))
                win32gui.DrawIconEx(hdc,sx2-sz//2,sy2-sz//2,icon,sz,sz,0,0,DI_NORMAL)
        user32.ReleaseDC(None,hdc)
        cx+=vx; cy+=vy
        if cx<RM or cx>SW-RM: vx=-vx
        if cy<RM or cy>SH-RM: vy=-vy
        aa=(aa+0.04)%(2*_m.pi); ab=(ab+0.025)%(2*_m.pi)
        time.sleep(0.033)
'''},
  {"name":"zoom_icons","label":"Zoom Pixel + Icons","cat":"Icons",
   "desc":"Pulsating pixelation with raining DLL icons",
   "deps":["math","win32gui","win32con"],"audio":"","thread":"effect_zoom_icons",
   "code":'''\
def effect_zoom_icons():
    import win32gui,win32con
    _dlls=[ctypes.windll.kernel32.LoadLibraryW("imageres.dll"),
           ctypes.windll.kernel32.LoadLibraryW("shell32.dll"),
           ctypes.windll.kernel32.LoadLibraryW("moricons.dll")]
    zt=0.0
    while running:
        zt+=0.008
        ps=max(2,int(2+abs(math.sin(zt))*12))
        bw=max(1,SW//ps); bh=max(1,SH//ps)
        hdc=user32.GetDC(0)
        hdcs=gdi32.CreateCompatibleDC(hdc); hbms=gdi32.CreateCompatibleBitmap(hdc,bw,bh)
        gdi32.SelectObject(hdcs,hbms)
        gdi32.BitBlt(hdcs,0,0,bw,bh,hdc,0,0,SRCCOPY)
        gdi32.SetStretchBltMode(hdc,4)
        gdi32.StretchBlt(hdc,0,0,SW,SH,hdcs,0,0,bw,bh,SRCCOPY)
        gdi32.DeleteObject(hbms); gdi32.DeleteDC(hdcs)
        for _ in range(random.randint(10,24)):
            dll=random.choice(_dlls); ii=random.randint(0,300)
            isz=random.randint(16,150)
            x=random.randint(0,max(1,SW-isz)); y=random.randint(0,max(1,SH-isz))
            hicon=user32.LoadImageW(dll,ii,1,isz,isz,0)
            if hicon:
                user32.DrawIconEx(hdc,x,y,hicon,isz,isz,0,None,0x0003)
                user32.DestroyIcon(hicon)
        user32.ReleaseDC(0,hdc)
'''},
  # ── Mouse ────────────────────────────────────────────────
  {"name":"mouse_hold","label":"Hold Pointer","cat":"Mouse",
   "desc":"Locks the cursor in the center of the screen",
   "deps":[],"audio":"","thread":"effect_mouse_hold",
   "code":'''\
def effect_mouse_hold():
    cx=SW//2; cy=SH//2
    while running:
        user32.SetCursorPos(cx,cy)
        time.sleep(0.01)
'''},
  {"name":"mouse_shake","label":"Shake Mouse","cat":"Mouse",
   "desc":"Light cursor shaking (±15px)",
   "deps":[],"audio":"","thread":"effect_mouse_shake",
   "code":'''\
def effect_mouse_shake():
    class POINT2(ctypes.Structure):
        _fields_=[("x",ctypes.c_long),("y",ctypes.c_long)]
    while running:
        p=POINT2(); user32.GetCursorPos(ctypes.byref(p))
        user32.SetCursorPos(
            max(0,min(SW-1,p.x+random.randint(-15,15))),
            max(0,min(SH-1,p.y+random.randint(-15,15))))
        time.sleep(0.016)
'''},
  {"name":"mouse_hardshake","label":"Hard Shake Mouse","cat":"Mouse",
   "desc":"Extreme cursor shaking (±120px) with no pause",
   "deps":[],"audio":"","thread":"effect_mouse_hardshake",
   "code":'''\
def effect_mouse_hardshake():
    class POINT2(ctypes.Structure):
        _fields_=[("x",ctypes.c_long),("y",ctypes.c_long)]
    while running:
        p=POINT2(); user32.GetCursorPos(ctypes.byref(p))
        user32.SetCursorPos(
            max(0,min(SW-1,p.x+random.randint(-120,120))),
            max(0,min(SH-1,p.y+random.randint(-120,120))))
'''},
  {"name":"mouse_dvd","label":"DVD Bounce Mouse","cat":"Mouse",
   "desc":"Cursor bounces across the entire screen like DVD logo",
   "deps":[],"audio":"","thread":"effect_mouse_dvd",
   "code":'''\
def effect_mouse_dvd():
    x=float(SW//2); y=float(SH//2)
    vx=random.choice([-8,-6,6,8]); vy=random.choice([-7,-5,5,7])
    while running:
        x+=vx; y+=vy
        if x<=0:    x=0.0;      vx=abs(vx)
        if x>=SW-1: x=SW-1.0;   vx=-abs(vx)
        if y<=0:    y=0.0;      vy=abs(vy)
        if y>=SH-1: y=SH-1.0;   vy=-abs(vy)
        user32.SetCursorPos(int(x),int(y))
        time.sleep(0.008)
'''},
  # ── Pixel Shaders ───────────────────────────────────────
  {"name":"hue_shader","label":"Hue Shader (pankoza)","cat":"Pixel Shaders",
   "desc":"Faithful port of hslshader.cpp — double buffer + live HueState",
   "deps":["numpy"],"audio":"","thread":"effect_hue_shader",
   "code":'''\
def effect_hue_shader():
    import numpy as np

    class HueState:
        def __init__(self):
            self.red=0; self.green=0; self.blue=0; self.ifblue=False
        def next(self, length=239):
            if self.red!=length:
                self.red+=1
                return (self.red,0,length) if self.ifblue else (self.red,0,0)
            else:
                if self.green!=length:
                    self.green+=1; return (length,self.green,0)
                else:
                    if self.blue!=length:
                        self.blue+=1; return (0,length,self.blue)
                    else:
                        self.red=0; self.green=0; self.blue=0; self.ifblue=True
                        return (0,0,0)

    def precompute_hue_cycle():
        hs=HueState(); Rs,Gs,Bs=[],[],[]
        while True:
            r1,_,_=hs.next(); _,g2,_=hs.next(); _,_,b3=hs.next()
            Rs.append(r1); Gs.append(g2); Bs.append(b3)
            if hs.red==1 and hs.green==0 and hs.blue==0 and hs.ifblue: break
        return (np.array(Rs,dtype=np.uint8),
                np.array(Gs,dtype=np.uint8),
                np.array(Bs,dtype=np.uint8))

    w=SW; h=SH; size=w*h; SRCCOPY2=0x00CC0020; CHUNK_PX=300
    desk_init=user32.GetDC(None)
    hdcdc=gdi32.CreateCompatibleDC(desk_init)
    hbm=gdi32.CreateBitmap(w,h,1,32,None)
    gdi32.SelectObject(hdcdc,hbm)
    user32.ReleaseDC(None,desk_init)

    cR,cG,cB=precompute_hue_cycle()
    cycle_len=len(cR)

    buf=np.zeros((size*2,4),dtype=np.uint8)
    for i in range(size*2):
        ci=i%cycle_len
        buf[i,2]=cR[ci]; buf[i,1]=cG[ci]; buf[i,0]=cB[ci]

    hs=HueState()
    cycle_pos=(size*2)%cycle_len
    for _ in range(cycle_pos):
        hs.next(); hs.next(); hs.next()

    head=0
    while running:
        for _ in range(CHUNK_PX):
            r1,_,_=hs.next(); _,g2,_=hs.next(); _,_,b3=hs.next()
            buf[head,2]=r1; buf[head,1]=g2; buf[head,0]=b3
            mirror=(head+size) if head<size else (head-size)
            buf[mirror,2]=r1; buf[mirror,1]=g2; buf[mirror,0]=b3
            head=(head+1)%size
        view=buf[head:head+size].ravel()
        desk=user32.GetDC(None)
        gdi32.SetBitmapBits(hbm,size*4,view.ctypes.data_as(ctypes.c_void_p))
        gdi32.BitBlt(desk,0,0,w,h,hdcdc,0,0,SRCCOPY2)
        user32.ReleaseDC(None,desk)
'''},
  # ── Bytebeat Audio ───────────────────────────────────────
  {"name":"audio_1","label":"Bytebeat: t*(43&t>>9)","cat":"Audio",
   "desc":"Classic bytebeat — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_1","thread":"","code":"",
   "bb_code":"def _bb_audio_1(t): return (t*(43&(t>>9)))&0xFF\n"},
  {"name":"audio_2","label":"Bytebeat: 2t&t>>8 (Xmas)","cat":"Audio",
   "desc":"Xmas bytebeat — 22050 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":22050,
   "bb_fn":"_bb_audio_2","thread":"","code":"",
   "bb_code":"def _bb_audio_2(t): return ((2*t&t>>8)|(5*t&t>>7)|(9*t&t>>4)|(15*t&t>>4))&0xFF\n"},
  {"name":"audio_20","label":"Bytebeat: t%(t>>8|1)","cat":"Audio",
   "desc":"glitch — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_20","thread":"","code":"",
   "bb_code":"def _bb_audio_20(t): return (t%max(1,t>>8|1)^t)&0xFF\n"},
  # ── new bytebeats ────────────────────────────────────────
  {"name":"audio_3","label":"Bytebeat: robocop - classic","cat":"Audio",
   "desc":"(t>>2)*(t&(16|24 sel by bit)|t>>(t>>8&24))|t>>3 — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_3","thread":"","code":"",
   "bb_code":"def _bb_audio_3(t): return (((t>>2)*((t&(16 if t&32768 else 24))|(t>>(t>>8&24))))|t>>3)&0xFF\n"},
  {"name":"audio_4","label":"Bytebeat: t*(t>>5|t>>8)","cat":"Audio",
   "desc":"Harmonic glitch — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_4","thread":"","code":"",
   "bb_code":"def _bb_audio_4(t): return (t*(t>>5|t>>8)>>(t>>16))&0xFF\n"},
  {"name":"audio_5","label":"Bytebeat: 5t&t>>7 | 3t&t>>10","cat":"Audio",
   "desc":"Dual-voice FM — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_5","thread":"","code":"",
   "bb_code":"def _bb_audio_5(t): return ((t*5&t>>7)|(t*3&t>>10))&0xFF\n"},
  {"name":"audio_6","label":"Bytebeat: sierpinski carpet","cat":"Audio",
   "desc":"t>>4|t>>(t>>4) — carpet texture — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_6","thread":"","code":"",
   "bb_code":"def _bb_audio_6(t): return (t>>4|t>>(t>>4))&0xFF\n"},
  {"name":"audio_7","label":"Bytebeat: stutter kick","cat":"Audio",
   "desc":"t*(t>>9|t>>13)&16&t>>6 — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_7","thread":"","code":"",
   "bb_code":"def _bb_audio_7(t): return (t*(t>>9|t>>13)&16&t>>6)&0xFF\n"},
  {"name":"audio_8","label":"Bytebeat: mellow drone","cat":"Audio",
   "desc":"(t>>6|t|t>>(t>>16))*10+(t>>11&7) — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_8","thread":"","code":"",
   "bb_code":"def _bb_audio_8(t): return ((t>>6|t|t>>(t>>16))*10+((t>>11)&7))&0xFF\n"},
  {"name":"audio_9","label":"Bytebeat: acid bass","cat":"Audio",
   "desc":"42*t&t>>10 — 16000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":16000,
   "bb_fn":"_bb_audio_9","thread":"","code":"",
   "bb_code":"def _bb_audio_9(t): return (42*t&t>>10)&0xFF\n"},
  {"name":"audio_10","label":"Bytebeat: arpeggio","cat":"Audio",
   "desc":"t*((t>>9&1)+1)>>4 — squeaky arpeggio — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_10","thread":"","code":"",
   "bb_code":"def _bb_audio_10(t): return (t*((t>>9&1)+1)>>4)&0xFF\n"},
  {"name":"audio_11","label":"Bytebeat: t^t>>8","cat":"Audio",
   "desc":"XOR cascade — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_11","thread":"","code":"",
   "bb_code":"def _bb_audio_11(t): return (t^t>>8^t>>3^t>>14)&0xFF\n"},
  {"name":"audio_12","label":"Bytebeat: evil organ","cat":"Audio",
   "desc":"(t|t>>1|t>>3)*(t>>4|t>>7) — 8000 Hz",
   "deps":["pyaudio"],"is_audio":True,"bb_rate":8000,
   "bb_fn":"_bb_audio_12","thread":"","code":"",
   "bb_code":"def _bb_audio_12(t): return ((t|t>>1|t>>3)*(t>>4|t>>7))&0xFF\n"},
]

# ════════════════════════════════════════════════════════════
#  GENERATED SCRIPT TEMPLATE
# ════════════════════════════════════════════════════════════
SCRIPT_HEADER = '''\
#!/usr/bin/env python3
# Generated by TauKit
import ctypes, ctypes.wintypes as wt, random, threading, time, math

user32 = ctypes.windll.user32
gdi32  = ctypes.windll.gdi32
SW = user32.GetSystemMetrics(0)
SH = user32.GetSystemMetrics(1)
SRCCOPY   = 0x00CC0020
SRCINVERT = 0x00660046
SRCPAINT  = 0x00EE0086
NOTSRCCOPY= 0x00330008

running = True

class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [
        ("biSize",wt.DWORD),("biWidth",wt.LONG),("biHeight",wt.LONG),
        ("biPlanes",wt.WORD),("biBitCount",wt.WORD),("biCompression",wt.DWORD),
        ("biSizeImage",wt.DWORD),("biXPelsPerMeter",wt.LONG),
        ("biYPelsPerMeter",wt.LONG),("biClrUsed",wt.DWORD),("biClrImportant",wt.DWORD),
    ]

class RGBTRIPLE(ctypes.Structure):
    _fields_ = [("rgbtBlue",ctypes.c_ubyte),("rgbtGreen",ctypes.c_ubyte),("rgbtRed",ctypes.c_ubyte)]

'''

# ════════════════════════════════════════════════════════════
#  CUSTOM BYTEBEAT DEFAULT TEMPLATE
# ════════════════════════════════════════════════════════════
_BB_TEMPLATE = "t*(43&t>>9)"

# ════════════════════════════════════════════════════════════
#  CUSTOM GDI DEFAULT TEMPLATE (inner body — each line auto-indented)
# ════════════════════════════════════════════════════════════
_GDI_TEMPLATE = """\
hdc = user32.GetDC(0)
# your GDI code here
gdi32.BitBlt(hdc, random.randint(-20, 20), random.randint(-20, 20),
             SW, SH, hdc, 0, 0, SRCCOPY)
user32.ReleaseDC(0, hdc)
"""

# ════════════════════════════════════════════════════════════
#  THEME
# ════════════════════════════════════════════════════════════
BG  = "#0d0d0d"
BG2 = "#161616"
BG3 = "#202020"
BG4 = "#2a2a2a"
FG  = "#c8c8c8"
FG2 = "#666666"
FG3 = "#3a3a3a"
SEL = "#1e3a1e"
HL  = "#2a5a2a"
ERR = "#5a1a1a"
ACC = "#4a7c4a"
FM  = ("Courier New", 9)
FB  = ("Courier New", 9, "bold")
FSM = ("Courier New", 8)
FT  = ("Courier New", 10, "bold")

def _e(parent, var, w=None, **kw):
    kwargs = dict(textvariable=var, font=FM, bg=BG3, fg=FG,
                  insertbackground=FG, relief="flat", bd=2,
                  highlightthickness=1, highlightbackground=FG3,
                  highlightcolor=FG2)
    if w: kwargs["width"] = w
    kwargs.update(kw)
    e = tk.Entry(parent, **kwargs)
    e.pack(side="left", fill="x", expand=True)
    return e

def _btn(parent, text, cmd, fg=FG, bg=BG3, **kw):
    b = tk.Button(parent, text=text, command=cmd,
                  font=FSM, bg=bg, fg=fg, relief="flat",
                  activebackground=BG2, activeforeground=FG,
                  cursor="hand2", padx=6, pady=2,
                  highlightthickness=0, **kw)
    return b

def _lbl(parent, text, fg=FG2, font=None, **kw):
    return tk.Label(parent, text=text, font=font or FSM,
                    bg=BG, fg=fg, **kw)

def _sep(parent, color=FG3):
    tk.Frame(parent, bg=color, height=1).pack(fill="x", pady=5)

def _section(parent, title):
    r = tk.Frame(parent, bg=BG)
    r.pack(fill="x", pady=(8, 2))
    tk.Label(r, text=title, font=FB, bg=BG, fg=FG).pack(side="left")
    tk.Frame(r, bg=FG3, height=1).pack(side="left", fill="x", expand=True, padx=(8,0), pady=4)

# ════════════════════════════════════════════════════════════
#  EFFECT TREE WIDGET
# ════════════════════════════════════════════════════════════
class EffectTree(tk.Frame):
    def __init__(self, parent, effects, checks, on_change=None, **kw):
        super().__init__(parent, bg=BG, **kw)
        self._effects   = effects
        self._checks    = checks
        self._on_change = on_change
        self._items     = {}
        self._build()

    def _build(self):
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)
        self.tree = ttk.Treeview(self, show="tree headings",
                                 columns=("sel","name","desc","deps"),
                                 selectmode="extended")
        self.tree.heading("#0",   text="",     anchor="w")
        self.tree.heading("sel",  text="",     anchor="center")
        self.tree.heading("name", text="name", anchor="w")
        self.tree.heading("desc", text="description", anchor="w")
        self.tree.heading("deps", text="deps", anchor="w")
        self.tree.column("#0",   width=0,   stretch=False)
        self.tree.column("sel",  width=24,  stretch=False, anchor="center")
        self.tree.column("name", width=200, stretch=False)
        self.tree.column("desc", width=300)
        self.tree.column("deps", width=90,  stretch=False)
        vsb = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        self.tree.tag_configure("cat",   background=BG2, foreground=FG2, font=FB)
        self.tree.tag_configure("item",  background=BG,  foreground=FG)
        self.tree.tag_configure("check", background=SEL, foreground=FG)
        self.tree.bind("<space>",           self._toggle_sel)
        self.tree.bind("<Return>",          self._toggle_sel)
        self.tree.bind("<Button-1>",        self._click)
        self.tree.bind("<Double-Button-1>", self._toggle_sel)
        cats = {}
        for ef in self._effects:
            cats.setdefault(ef["cat"], []).append(ef)
        for cat, efs in cats.items():
            cid = self.tree.insert("", "end", iid=f"cat_{cat}",
                                   values=("", f"[{cat}]", "", ""),
                                   tags=("cat",), open=True)
            for ef in efs:
                iid = f"ef_{ef['name']}"
                self._items[iid] = ef["name"]
                deps = ",".join(ef.get("deps", []))
                self.tree.insert(cid, "end", iid=iid,
                                 values=(" ", ef["label"], ef["desc"], deps),
                                 tags=("item",))

    def _click(self, event):
        if self.tree.identify("region", event.x, event.y) == "cell":
            iid = self.tree.identify("row", event.x, event.y)
            if iid in self._items:
                self._toggle(iid)

    def _toggle_sel(self, event=None):
        for iid in self.tree.selection():
            if iid in self._items:
                self._toggle(iid)

    def _toggle(self, iid):
        name = self._items[iid]
        self._checks[name].set(not self._checks[name].get())
        self._refresh_row(iid, name)
        if self._on_change:
            self._on_change()

    def _refresh_row(self, iid, name):
        checked = self._checks[name].get()
        cur = self.tree.item(iid, "values")
        self.tree.item(iid,
                       tags=("check",) if checked else ("item",),
                       values=("x" if checked else " ", cur[1], cur[2], cur[3]))

    def set_all(self, v):
        for iid, name in self._items.items():
            self._checks[name].set(v)
            self._refresh_row(iid, name)
        if self._on_change:
            self._on_change()

    def count_selected(self):
        return sum(1 for iid, n in self._items.items() if self._checks[n].get())


# ════════════════════════════════════════════════════════════
#  MAIN APP
# ════════════════════════════════════════════════════════════
class TauKit(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("TauKit 1.10")
        self.configure(bg=BG)
        self.resizable(True, True)
        self.minsize(900, 580)
        self.option_add("*tearOff", False)

        self.checks      = {ef["name"]: tk.BooleanVar() for ef in EFFECTS}
        self.phases      = []
        self.use_phases  = tk.BooleanVar(value=False)
        self.phase_dur   = tk.StringVar(value="20")
        self.out_dir     = tk.StringVar(value=os.path.expanduser("~"))
        self.out_name    = tk.StringVar(value="gdi_output.py")
        self.out_path    = tk.StringVar()
        self.icon_path   = tk.StringVar()
        self.do_compile  = tk.BooleanVar(value=False)
        self.onefile     = tk.BooleanVar(value=True)
        self.noconsole   = tk.BooleanVar(value=True)
        self.mb1_enabled = tk.BooleanVar(value=False)
        self.mb1_title   = tk.StringVar(value="Warning")
        self.mb1_msg     = tk.StringVar(value="Are you sure?")
        self.mb2_enabled = tk.BooleanVar(value=False)
        self.mb2_title   = tk.StringVar(value="Final Warning")
        self.mb2_msg     = tk.StringVar(value="Last chance to cancel.")

        # ── custom effects state ──────────────────────────────
        # each entry: {"label": StringVar, "code_widget": Text, "sleep": StringVar}
        self._custom_gdis  = []
        # each entry: {"label": StringVar, "formula": StringVar, "rate": StringVar}
        self._custom_bbs   = []
        self._cg_frame     = None   # inner frame for custom GDI rows
        self._cb_frame     = None   # inner frame for custom BB rows

        self._log_buf = []
        self._log_win = None
        self._build()

    # ── chrome ───────────────────────────────────────────────
    def _build(self):
        self._style()
        mb = tk.Menu(self, bg=BG2, fg=FG, activebackground=BG3,
                     activeforeground=FG, relief="flat", bd=0)
        self.configure(menu=mb)
        fm = tk.Menu(mb, bg=BG2, fg=FG, activebackground=BG3,
                     activeforeground=FG, relief="flat")
        mb.add_cascade(label="File", menu=fm)
        fm.add_command(label="Generate Script", command=self._generate)
        fm.add_separator()
        fm.add_command(label="Exit", command=self.destroy)
        sm = tk.Menu(mb, bg=BG2, fg=FG, activebackground=BG3,
                     activeforeground=FG, relief="flat")
        mb.add_cascade(label="Select", menu=sm)
        sm.add_command(label="All Effects",   command=lambda: self._set_all(True))
        sm.add_command(label="No Effects",    command=lambda: self._set_all(False))
        sm.add_command(label="GDI Only",      command=lambda: self._set_by(lambda e: not bool(e.get("is_audio"))))
        sm.add_command(label="Audio Only",    command=lambda: self._set_by(lambda e: bool(e.get("is_audio"))))

        strip = tk.Frame(self, bg=BG2, pady=3)
        strip.pack(fill="x")
        tk.Label(strip, text="TauKit 1.10", font=FT,  bg=BG2, fg=FG).pack(side="left", padx=10)
        tk.Label(strip, text="─", font=FSM, bg=BG2, fg=FG3).pack(side="left")
        tk.Label(strip, text="GDI Effects Builder",
                 font=FSM, bg=BG2, fg=FG2).pack(side="left", padx=4)
        self.status_lbl = tk.Label(strip, text="", font=FSM, bg=BG2, fg=FG2)
        self.status_lbl.pack(side="right", padx=10)

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True)

        self._tab_about(nb)
        self._tab_gdi(nb)
        self._tab_bytebeat(nb)
        self._tab_custom(nb)        # ← new tab
        self._tab_warning(nb)
        self._tab_build(nb)
        self._tab_phases(nb)

        logf = tk.Frame(self, bg=BG2)
        logf.pack(fill="x")
        tk.Label(logf, text=" log>", font=FSM, bg=BG2, fg=FG3).pack(side="left")
        self.log_line = tk.Label(logf, text="ready.", font=FSM,
                                 bg=BG2, fg=FG2, anchor="w")
        self.log_line.pack(side="left", fill="x", expand=True)
        _btn(logf, "▼ full log", self._show_log).pack(side="right", padx=4, pady=2)

    def _style(self):
        s = ttk.Style(self)
        s.theme_use("clam")
        s.configure("TNotebook",
                    background=BG, borderwidth=0, tabmargins=[0,2,0,0])
        s.configure("TNotebook.Tab",
                    background=BG2, foreground=FG2,
                    font=("Courier New", 9), padding=[14, 4], borderwidth=0)
        s.map("TNotebook.Tab",
              background=[("selected", BG3)],
              foreground=[("selected", FG)])
        s.configure("Treeview",
                    background=BG, foreground=FG,
                    fieldbackground=BG, rowheight=18, font=FM, borderwidth=0)
        s.configure("Treeview.Heading",
                    background=BG2, foreground=FG2, font=FB, relief="flat")
        s.map("Treeview",
              background=[("selected", SEL)],
              foreground=[("selected", FG)])
        s.configure("Vertical.TScrollbar",
                    background=BG3, troughcolor=BG2,
                    borderwidth=0, arrowsize=10)

    # ════════════════════════════════════════════════════════
    #  TAB 1 — ABOUT
    # ════════════════════════════════════════════════════════
    def _tab_about(self, nb):
        f = tk.Frame(nb, bg=BG)
        nb.add(f, text="  about  ")
        inner = tk.Frame(f, bg=BG)
        inner.place(relx=0.5, rely=0.42, anchor="center")
        tk.Label(inner, text="TauKit 1.10", font=("Courier New",22,"bold"),
                 bg=BG, fg=FG).pack(pady=(0,4))
        tk.Label(inner, text="Create GDIwares without coding?",
                 font=("Courier New",11,"bold"), bg=BG, fg=ACC).pack()
        tk.Frame(inner, bg=FG3, height=1, width=360).pack(pady=14)
        tk.Label(inner, text="Using python, pyinstaller, pyaudio and ctypes, its now ready.\n"
                             "Here it is (pure notepad artwork i think lmao!)\n"
                             "For coders that dont know GDI(+). hope you enjoy!",
                 font=FSM, bg=BG, fg=FG2, justify="center").pack(pady=8)
        tk.Frame(inner, bg=FG3, height=1, width=360).pack(pady=14)
        rows = [
            ("gdi effects",  f"{sum(1 for e in EFFECTS if not e.get('is_audio'))} visual effects"),
            ("bytebeat",     f"{sum(1 for e in EFFECTS if e.get('is_audio'))} audio synths"),
            ("categories",   ", ".join(sorted({e['cat'] for e in EFFECTS if not e.get('is_audio')}))),
            ("output",       "python 3 script  /  pyinstaller exe"),
            ("phase mode",   "sequence effects with time-based phases"),
            ("custom",       "write your own GDI loop or bytebeat formula"),
        ]
        for k, v in rows:
            r = tk.Frame(inner, bg=BG)
            r.pack(fill="x", pady=1)
            tk.Label(r, text=f"{k:<14}", font=FSM, bg=BG, fg=FG3).pack(side="left")
            tk.Label(r, text=v,          font=FSM, bg=BG, fg=FG2).pack(side="left")
        tk.Frame(inner, bg=FG3, height=1, width=360).pack(pady=14)
        quick = tk.Frame(inner, bg=BG)
        quick.pack()
        _btn(quick, "select all gdi",    lambda: self._set_by(lambda e: not bool(e.get("is_audio"))),
             fg=FG, bg=BG4).pack(side="left", padx=4)
        _btn(quick, "select all audio",  lambda: self._set_by(lambda e: bool(e.get("is_audio"))),
             fg=FG, bg=BG4).pack(side="left", padx=4)
        _btn(quick, "generate script",   self._generate,
             fg=FG, bg=ACC).pack(side="left", padx=4)

    # ════════════════════════════════════════════════════════
    #  TAB 2 — GDI
    # ════════════════════════════════════════════════════════
    def _tab_gdi(self, nb):
        f = tk.Frame(nb, bg=BG)
        nb.add(f, text="  GDI  ")
        f.rowconfigure(1, weight=1)
        f.columnconfigure(0, weight=1)
        tb = tk.Frame(f, bg=BG2, pady=3)
        tb.grid(row=0, column=0, sticky="ew")
        tk.Label(tb, text="  visual effects", font=FB, bg=BG2, fg=FG).pack(side="left")
        tk.Frame(tb, bg=FG3, width=1).pack(side="left", fill="y", padx=8, pady=2)
        for lbl, cats in [
            ("[all]",    None),("[none]",   None),
            ("[scroll]", "Scroll / Blit"),("[distort]","Distortion"),
            ("[pixels]", "Pixels / Color"),("[draw]",   "Drawing"),
            ("[text]",   "Text"),("[icons]",  "Icons"),
            ("[mouse]",  "Mouse"),("[shader]", "Pixel Shaders"),
        ]:
            if lbl == "[all]":
                cmd = lambda: self._gdi_tree.set_all(True)
            elif lbl == "[none]":
                cmd = lambda: self._gdi_tree.set_all(False)
            else:
                _cat = cats
                cmd = lambda c=_cat: self._set_cat(c, True)
            _btn(tb, lbl, cmd).pack(side="left", padx=1)
        self.gdi_sel_lbl = tk.Label(tb, text="0 selected", font=FSM, bg=BG2, fg=FG3)
        self.gdi_sel_lbl.pack(side="right", padx=8)
        gdi_effects = [e for e in EFFECTS if not e.get("is_audio")]
        self._gdi_tree = EffectTree(f, gdi_effects, self.checks,
                                    on_change=self._update_sel_lbls)
        self._gdi_tree.grid(row=1, column=0, sticky="nsew")

    # ════════════════════════════════════════════════════════
    #  TAB 3 — BYTEBEAT
    # ════════════════════════════════════════════════════════
    def _tab_bytebeat(self, nb):
        f = tk.Frame(nb, bg=BG)
        nb.add(f, text="  bytebeat  ")
        f.rowconfigure(2, weight=1)
        f.columnconfigure(0, weight=1)
        tb = tk.Frame(f, bg=BG2, pady=3)
        tb.grid(row=0, column=0, sticky="ew")
        tk.Label(tb, text="  bytebeat synths", font=FB, bg=BG2, fg=FG).pack(side="left")
        tk.Frame(tb, bg=FG3, width=1).pack(side="left", fill="y", padx=8, pady=2)
        _btn(tb, "[all]",  lambda: self._bb_tree.set_all(True) ).pack(side="left", padx=1)
        _btn(tb, "[none]", lambda: self._bb_tree.set_all(False)).pack(side="left", padx=1)
        self.bb_sel_lbl = tk.Label(tb, text="0 selected", font=FSM, bg=BG2, fg=FG3)
        self.bb_sel_lbl.pack(side="right", padx=8)
        info = tk.Frame(f, bg=BG2, pady=4)
        info.grid(row=1, column=0, sticky="ew")
        tk.Label(info,
                 text="  requires: pip install pyaudio   |   one synth plays at a time, cycles every 12 s",
                 font=FSM, bg=BG2, fg=FG2).pack(side="left", padx=6)
        bb_effects = [e for e in EFFECTS if e.get("is_audio")]
        self._bb_tree = EffectTree(f, bb_effects, self.checks,
                                   on_change=self._update_sel_lbls)
        self._bb_tree.grid(row=2, column=0, sticky="nsew")

    # ════════════════════════════════════════════════════════
    #  TAB 4 — CUSTOM  ← new
    # ════════════════════════════════════════════════════════
    def _tab_custom(self, nb):
        outer = tk.Frame(nb, bg=BG)
        nb.add(outer, text="  custom  ")

        # scrollable outer container
        canvas = tk.Canvas(outer, bg=BG, highlightthickness=0, bd=0)
        vsb    = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        canvas.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")
        f = tk.Frame(canvas, bg=BG, padx=14, pady=10)
        wid = canvas.create_window((0,0), window=f, anchor="nw")
        f.bind("<Configure>",
               lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>",
                    lambda e: canvas.itemconfig(wid, width=e.width))

        # ── CUSTOM GDI section ────────────────────────────────
        _section(f, "custom GDI effects")
        tk.Label(f,
                 text="Each block runs inside its own thread.  Write the loop body (access user32/gdi32/SW/SH/running).",
                 font=FSM, bg=BG, fg=FG2, wraplength=600, justify="left").pack(anchor="w", pady=(0,4))

        cg_toolbar = tk.Frame(f, bg=BG)
        cg_toolbar.pack(fill="x", pady=(0,4))
        _btn(cg_toolbar, "+ add GDI block", self._add_custom_gdi,
             fg=FG, bg=HL).pack(side="left")
        tk.Label(cg_toolbar, text="  (max 8)", font=FSM, bg=BG, fg=FG3).pack(side="left")

        self._cg_frame = tk.Frame(f, bg=BG)
        self._cg_frame.pack(fill="x")

        _sep(f)

        # ── CUSTOM BYTEBEAT section ───────────────────────────
        _section(f, "custom bytebeat formulas")
        tk.Label(f,
                 text="Formula uses variable t (integer sample counter).  Result is &0xFF automatically.\n"
                      "Example:  t*(43&t>>9)   or   (t>>4|t>>(t>>4))   or   t^(t>>8)^(t>>3)",
                 font=FSM, bg=BG, fg=FG2, justify="left").pack(anchor="w", pady=(0,4))

        cb_toolbar = tk.Frame(f, bg=BG)
        cb_toolbar.pack(fill="x", pady=(0,4))
        _btn(cb_toolbar, "+ add formula", self._add_custom_bb,
             fg=FG, bg=HL).pack(side="left")

        # header row
        hdr = tk.Frame(f, bg=BG2)
        hdr.pack(fill="x", pady=(2,0))
        for txt, wd in [("label", 160), ("formula", 0), ("rate", 68), ("", 54)]:
            tk.Label(hdr, text=txt, font=FB, bg=BG2, fg=FG2,
                     width=0, anchor="w").pack(side="left",
                     padx=6 if txt=="label" else 2, pady=2)
        self._cb_frame = tk.Frame(f, bg=BG)
        self._cb_frame.pack(fill="x")

    def _add_custom_gdi(self):
        if len(self._custom_gdis) >= 8:
            messagebox.showinfo("TauKit", "max 8 custom GDI blocks"); return
        idx = len(self._custom_gdis)
        entry = {
            "label":  tk.StringVar(value=f"my_effect_{idx}"),
            "sleep":  tk.StringVar(value="0.0"),
        }

        row_outer = tk.Frame(self._cg_frame, bg=BG3, padx=6, pady=4)
        row_outer.pack(fill="x", pady=3)

        hdr_row = tk.Frame(row_outer, bg=BG3)
        hdr_row.pack(fill="x")
        tk.Label(hdr_row, text="label:", font=FSM, bg=BG3, fg=FG2).pack(side="left")
        tk.Entry(hdr_row, textvariable=entry["label"], font=FM, bg=BG4, fg=FG,
                 insertbackground=FG, relief="flat", bd=1, width=22,
                 highlightthickness=1, highlightbackground=FG3).pack(side="left", padx=4)
        tk.Label(hdr_row, text="sleep(s):", font=FSM, bg=BG3, fg=FG2).pack(side="left", padx=(10,0))
        tk.Entry(hdr_row, textvariable=entry["sleep"], font=FM, bg=BG4, fg=FG,
                 insertbackground=FG, relief="flat", bd=1, width=6,
                 highlightthickness=1, highlightbackground=FG3).pack(side="left", padx=4)
        def _rm(ro=row_outer, en=entry):
            self._custom_gdis.remove(en); ro.destroy()
        _btn(hdr_row, "remove", _rm, fg="#aa4444").pack(side="right")

        code_box = scrolledtext.ScrolledText(
            row_outer, font=("Courier New", 8), bg="#111111", fg="#aaffaa",
            insertbackground=FG, relief="flat", bd=0, height=6,
            wrap="none", highlightthickness=1, highlightbackground=FG3)
        code_box.pack(fill="x", pady=(4,0))
        code_box.insert("end", _GDI_TEMPLATE)

        entry["code_widget"] = code_box
        self._custom_gdis.append(entry)

    def _add_custom_bb(self):
        idx = len(self._custom_bbs)
        entry = {
            "label":   tk.StringVar(value=f"custom_bb_{idx}"),
            "formula": tk.StringVar(value=_BB_TEMPLATE),
            "rate":    tk.StringVar(value="8000"),
        }
        row = tk.Frame(self._cb_frame, bg=BG3 if idx%2==0 else BG, pady=2)
        row.pack(fill="x")

        tk.Entry(row, textvariable=entry["label"], font=FM, bg=BG4, fg=FG,
                 insertbackground=FG, relief="flat", bd=1, width=18,
                 highlightthickness=1, highlightbackground=FG3).pack(side="left", padx=(4,2))
        tk.Entry(row, textvariable=entry["formula"], font=FM, bg=BG4, fg="#aaffaa",
                 insertbackground=FG, relief="flat", bd=1,
                 highlightthickness=1, highlightbackground=FG3).pack(side="left", fill="x",
                                                                      expand=True, padx=2)
        tk.Entry(row, textvariable=entry["rate"], font=FM, bg=BG4, fg=FG,
                 insertbackground=FG, relief="flat", bd=1, width=7,
                 highlightthickness=1, highlightbackground=FG3).pack(side="left", padx=2)
        def _rm(r=row, en=entry):
            self._custom_bbs.remove(en); r.destroy()
        _btn(row, "del", _rm, fg="#aa4444").pack(side="right", padx=4)

        self._custom_bbs.append(entry)

    # ════════════════════════════════════════════════════════
    #  TAB 5 — WARNING NOTE
    # ════════════════════════════════════════════════════════
    def _tab_warning(self, nb):
        f = tk.Frame(nb, bg=BG, padx=14, pady=10)
        nb.add(f, text="  warning note  ")
        tk.Label(f,
                 text="Startup MessageBox — shown before effects run. User must click OK to continue.",
                 font=FSM, bg=BG, fg=FG2).pack(anchor="w", pady=(0,6))
        _sep(f)

        def _msgbox_block(parent, idx, en_var, ti_var, ms_var):
            _section(parent, f"msgbox {idx+1}")
            hdr = tk.Frame(parent, bg=BG)
            hdr.pack(fill="x", pady=(0,4))
            tk.Checkbutton(hdr, text=f"enable msgbox {idx+1}", variable=en_var,
                           font=FM, bg=BG, fg=FG, selectcolor=BG3,
                           activebackground=BG, relief="flat", cursor="hand2").pack(side="left")
            def row(lbl, var):
                r = tk.Frame(parent, bg=BG)
                r.pack(fill="x", pady=2)
                tk.Label(r, text=f"{lbl:<10}", font=FM, bg=BG, fg=FG2).pack(side="left")
                _e(r, var)
            row("title",   ti_var)
            row("message", ms_var)
            cv = tk.Canvas(parent, bg=BG, highlightthickness=0, height=148)
            cv.pack(fill="x", padx=20, pady=(6,12))
            def draw(cv=cv, ti=ti_var, ms=ms_var, idx=idx):
                cv.delete("all")
                W = cv.winfo_width() or 340; H = 148
                for s in range(4, 0, -1):
                    shade = "#%02x%02x%02x" % (s*20,s*20,s*20)
                    cv.create_rectangle(s+2,s+2,W-2+s,H-2+s, fill=shade,outline="")
                cv.create_rectangle(2,2,W-4,H-4, fill="#f0f0f0",outline="#999999")
                cv.create_rectangle(3,3,W-5,H-5, fill="#f0f0f0",outline="#ffffff")
                for row in range(29):
                    t2=row/28.0
                    r2=int(0x00+(0x28-0x00)*t2); g2v=int(0x78+(0x28-0x78)*t2); b2=int(0xd4+(0x90-0xd4)*t2)
                    cv.create_line(3,4+row,W-5,4+row, fill="#%02x%02x%02x"%(r2,g2v,b2))
                cv.create_text(8,18, text=ti.get() or f"msgbox {idx+1}",
                               font=("Segoe UI",9,"bold"), fill="white", anchor="w")
                bx=W-7
                for ox2,lbl2,col2 in [(bx-22,"✕","#c42b1c"),(bx-46,"□","#3a3a3a"),(bx-70,"─","#3a3a3a")]:
                    cv.create_rectangle(ox2,5,ox2+20,27,fill=col2,outline=col2)
                    cv.create_text(ox2+10,16,text=lbl2,font=("Segoe UI",8,"bold"),fill="white",anchor="center")
                cv.create_line(3,33,W-5,33, fill="#0050a0")
                ix,iy=30,75
                cv.create_polygon(ix,iy-22,ix-19,iy+12,ix+19,iy+12, fill="#ffcc00",outline="#cc8800",width=2)
                cv.create_text(ix,iy-4, text="!", font=("Arial",14,"bold"),fill="#1a1a00",anchor="center")
                cv.create_text(58,58, text=ms.get() or "(no message)",
                               font=("Segoe UI",9), fill="#1a1a1a", anchor="nw", width=W-70)
                cv.create_line(3,H-38,W-5,H-38, fill="#d0d0d0")
                cv.create_rectangle(3,H-37,W-5,H-5, fill="#f0f0f0",outline="")
                bw=75; bh=23; by2=H-28
                ox3=W-10-bw
                cv.create_rectangle(ox3-1,by2-1,ox3+bw+1,by2+bh+1, fill="#0067c0",outline="#0067c0")
                cv.create_rectangle(ox3,by2,ox3+bw,by2+bh, fill="#e8e8e8",outline="")
                for br in range(bh):
                    gc=int(0xf5-br/(bh-1)*0x10)
                    cv.create_line(ox3+1,by2+br,ox3+bw-1,by2+br,fill="#%02x%02x%02x"%(gc,gc,gc))
                cv.create_text(ox3+bw//2,by2+bh//2,text="OK",font=("Segoe UI",9),fill="#1a1a1a",anchor="center")
                cx3=ox3-6-bw
                cv.create_rectangle(cx3,by2,cx3+bw,by2+bh, fill="#e8e8e8",outline="#adadad")
                for br in range(bh):
                    gc=int(0xf5-br/(bh-1)*0x08)
                    cv.create_line(cx3+1,by2+br,cx3+bw-1,by2+br,fill="#%02x%02x%02x"%(gc,gc,gc))
                cv.create_text(cx3+bw//2,by2+bh//2,text="Cancel",font=("Segoe UI",9),fill="#1a1a1a",anchor="center")
            cv.bind("<Configure>", lambda e, fn=draw: fn())
            cv.after(60, draw)
            ti_var.trace_add("write", lambda *_, fn=draw: fn())
            ms_var.trace_add("write", lambda *_, fn=draw: fn())

        _msgbox_block(f, 0, self.mb1_enabled, self.mb1_title, self.mb1_msg)
        _sep(f)
        _msgbox_block(f, 1, self.mb2_enabled, self.mb2_title, self.mb2_msg)

    # ════════════════════════════════════════════════════════
    #  TAB 6 — BUILD
    # ════════════════════════════════════════════════════════
    def _tab_build(self, nb):
        f = tk.Frame(nb, bg=BG, padx=14, pady=10)
        nb.add(f, text="  build  ")

        def row(parent, lbl, var, btn_cmd=None, btn_txt="browse"):
            r = tk.Frame(parent, bg=BG)
            r.pack(fill="x", pady=2)
            tk.Label(r, text=f"{lbl:<18}", font=FM, bg=BG, fg=FG2).pack(side="left")
            _e(r, var)
            if btn_cmd:
                _btn(r, btn_txt, btn_cmd).pack(side="right", padx=(4,0))

        _section(f, "output")
        row(f, "directory",  self.out_dir,  self._pick_dir)
        row(f, "filename",   self.out_name)
        self.path_lbl = tk.Label(f, text="", font=FSM, bg=BG, fg=FG3, anchor="w")
        self.path_lbl.pack(fill="x", padx=2, pady=(0,2))
        self.out_dir.trace_add("write",  lambda *_: self._upd_path())
        self.out_name.trace_add("write", lambda *_: self._upd_path())
        self._upd_path()

        _section(f, "icon")
        row(f, "icon file (.ico)", self.icon_path, self._pick_icon)

        _section(f, "pyinstaller")
        for text, var in [("compile with pyinstaller", self.do_compile),
                          ("--onefile",               self.onefile),
                          ("--noconsole",             self.noconsole)]:
            r = tk.Frame(f, bg=BG)
            r.pack(anchor="w", pady=1)
            tk.Checkbutton(r, text=text, variable=var, font=FM,
                           bg=BG, fg=FG, selectcolor=BG3,
                           activebackground=BG, relief="flat",
                           cursor="hand2").pack(side="left")

        _section(f, "dependencies")
        self.deps_lbl = tk.Label(f, text="none", font=FSM, bg=BG, fg=FG2,
                                 anchor="w", justify="left", wraplength=400)
        self.deps_lbl.pack(fill="x", padx=2, pady=(0,10))
        _sep(f)

        btn_row = tk.Frame(f, bg=BG)
        btn_row.pack(anchor="w")
        tk.Button(btn_row, text="  generate script  ",
                  font=FB, bg=ACC, fg=FG, relief="flat",
                  activebackground=HL, activeforeground=FG,
                  cursor="hand2", pady=6, padx=8,
                  highlightthickness=0,
                  command=self._generate).pack(side="left")
        self.gen_status = tk.Label(btn_row, text="", font=FSM, bg=BG, fg=FG2)
        self.gen_status.pack(side="left", padx=10)

        for var in self.checks.values():
            var.trace_add("write", lambda *_: self._update_deps())
        self._update_deps()

    # ════════════════════════════════════════════════════════
    #  TAB 7 — PHASES
    # ════════════════════════════════════════════════════════
    def _tab_phases(self, nb):
        f = tk.Frame(nb, bg=BG, padx=14, pady=10)
        nb.add(f, text="  phases  ")
        hdr = tk.Frame(f, bg=BG)
        hdr.pack(fill="x", pady=(0,4))
        tk.Checkbutton(hdr, text="enable phase mode", variable=self.use_phases,
                       font=FB, bg=BG, fg=FG, selectcolor=BG3,
                       activebackground=BG, relief="flat", cursor="hand2").pack(side="left")
        tk.Label(f, text="each phase runs the currently-checked effects for N seconds.",
                 font=FSM, bg=BG, fg=FG2).pack(anchor="w")
        tk.Label(f, text="check effects → set duration → add phase → repeat.",
                 font=FSM, bg=BG, fg=FG2).pack(anchor="w")
        _sep(f)
        add = tk.Frame(f, bg=BG)
        add.pack(fill="x", pady=4)
        tk.Label(add, text="duration (s)", font=FM, bg=BG, fg=FG2).pack(side="left")
        tk.Entry(add, textvariable=self.phase_dur, font=FM, bg=BG3, fg=FG,
                 insertbackground=FG, relief="flat", bd=2, width=6,
                 highlightthickness=1, highlightbackground=FG3).pack(side="left", padx=6)
        _btn(add, "+ add phase", self._add_phase, fg=FG, bg=HL).pack(side="left")
        _sep(f)
        tk.Label(f, text="phase list", font=FB, bg=BG, fg=FG).pack(anchor="w", pady=(0,2))
        list_canvas = tk.Canvas(f, bg=BG, highlightthickness=0, bd=0)
        list_vsb    = ttk.Scrollbar(f, orient="vertical", command=list_canvas.yview)
        list_canvas.configure(yscrollcommand=list_vsb.set)
        list_canvas.pack(side="left", fill="both", expand=True)
        list_vsb.pack(side="right", fill="y")
        self.phases_inner = tk.Frame(list_canvas, bg=BG)
        wid = list_canvas.create_window((0,0), window=self.phases_inner, anchor="nw")
        self.phases_inner.bind("<Configure>",
            lambda e: list_canvas.configure(scrollregion=list_canvas.bbox("all")))
        list_canvas.bind("<Configure>",
            lambda e: list_canvas.itemconfig(wid, width=e.width))
        self._refresh_phases()

    # ════════════════════════════════════════════════════════
    #  HELPERS
    # ════════════════════════════════════════════════════════
    def _set_all(self, v):
        for ef in EFFECTS:
            self.checks[ef["name"]].set(v)
        self._gdi_tree.set_all(v)
        self._bb_tree.set_all(v)
        self._update_sel_lbls()
        self._update_deps()

    def _set_by(self, pred):
        for ef in EFFECTS:
            self.checks[ef["name"]].set(pred(ef))
        for ef in EFFECTS:
            iid  = f"ef_{ef['name']}"
            tree = self._gdi_tree if not ef.get("is_audio") else self._bb_tree
            tree._refresh_row(iid, ef["name"])
        self._update_sel_lbls()
        self._update_deps()

    def _set_cat(self, cat, v):
        for ef in EFFECTS:
            if ef["cat"] == cat:
                self.checks[ef["name"]].set(v)
                tree = self._gdi_tree if not ef.get("is_audio") else self._bb_tree
                tree._refresh_row(f"ef_{ef['name']}", ef["name"])
        self._update_sel_lbls()
        self._update_deps()

    def _update_sel_lbls(self):
        try:
            gdi_n = self._gdi_tree.count_selected()
            bb_n  = self._bb_tree.count_selected()
            self.gdi_sel_lbl.config(text=f"{gdi_n} selected")
            self.bb_sel_lbl.config(text=f"{bb_n} selected")
        except Exception:
            pass

    def _update_deps(self):
        deps = set()
        for ef in EFFECTS:
            if self.checks.get(ef["name"], tk.BooleanVar()).get():
                deps.update(ef.get("deps", []))
        if self._custom_bbs:
            deps.add("pyaudio")
        try:
            self.deps_lbl.config(text=", ".join(sorted(deps)) or "none")
        except Exception:
            pass

    def _pick_dir(self):
        p = filedialog.askdirectory(initialdir=self.out_dir.get())
        if p: self.out_dir.set(p)

    def _pick_icon(self):
        p = filedialog.askopenfilename(filetypes=[("Icon","*.ico"),("All","*.*")])
        if p: self.icon_path.set(p)

    def _upd_path(self):
        d = self.out_dir.get().strip()
        n = self.out_name.get().strip() or "gdi_output.py"
        if not n.endswith(".py"): n += ".py"
        full = os.path.join(d, n) if d else n
        self.out_path.set(full)
        try: self.path_lbl.config(text=f"  -> {full}")
        except: pass

    def _log(self, msg):
        self._log_buf.append(msg)
        try: self.log_line.config(text=msg)
        except: pass
        if self._log_win and self._log_win.winfo_exists():
            self._log_win.append(msg)

    def _show_log(self):
        if self._log_win and self._log_win.winfo_exists():
            self._log_win.lift(); return
        w = tk.Toplevel(self)
        w.title("log"); w.configure(bg=BG); w.geometry("720x320")
        box = scrolledtext.ScrolledText(w, font=("Courier New",8),
                                        bg=BG3, fg=FG, insertbackground=FG,
                                        relief="flat", bd=0)
        box.pack(fill="both", expand=True, padx=4, pady=4)
        for line in self._log_buf:
            box.insert("end", line+"\n")
        box.see("end")
        box.configure(state="disabled")
        def append(msg):
            box.configure(state="normal")
            box.insert("end", msg+"\n"); box.see("end")
            box.configure(state="disabled")
        w.append = append
        self._log_win = w

    # ── phase management ─────────────────────────────────────
    def _add_phase(self):
        sel = [n for n, v in self.checks.items() if v.get()]
        if not sel:
            messagebox.showwarning("TauKit", "no effects selected"); return
        try:
            dur = int(self.phase_dur.get()); assert dur > 0
        except Exception:
            messagebox.showerror("TauKit", "invalid duration"); return
        labels = [ef["label"] for ef in EFFECTS if ef["name"] in sel]
        self.phases.append({
            "duration": dur, "effects": sel,
            "label": ", ".join(labels[:3]) + ("..." if len(labels) > 3 else "")
        })
        self._refresh_phases()
        self._log(f"phase {len(self.phases)} added  {dur}s  [{len(sel)} effects]")

    def _remove_phase(self, i):
        self.phases.pop(i); self._refresh_phases()

    def _move_phase(self, i, d):
        j = i + d
        if 0 <= j < len(self.phases):
            self.phases[i], self.phases[j] = self.phases[j], self.phases[i]
            self._refresh_phases()

    def _refresh_phases(self):
        for w in self.phases_inner.winfo_children(): w.destroy()
        if not self.phases:
            tk.Label(self.phases_inner, text="no phases", font=FSM,
                     bg=BG, fg=FG3).pack(anchor="w"); return
        h = tk.Frame(self.phases_inner, bg=BG2)
        h.pack(fill="x")
        for txt, wd in [("#",3),("dur",6),("effects","")]:
            tk.Label(h, text=txt, font=FB, bg=BG2, fg=FG2,
                     width=wd if isinstance(wd,int) else 0,
                     anchor="w").pack(side="left", padx=4 if txt=="#" else 2)
        for i, ph in enumerate(self.phases):
            r = tk.Frame(self.phases_inner, bg=BG3 if i%2==0 else BG)
            r.pack(fill="x", pady=1)
            tk.Label(r, text=f"{i+1}", font=FM, bg=r["bg"], fg=FG2,
                     width=3, anchor="e").pack(side="left", padx=4)
            tk.Label(r, text=f"{ph['duration']}s", font=FM, bg=r["bg"], fg=FG,
                     width=6, anchor="w").pack(side="left")
            tk.Label(r, text=ph["label"], font=FSM, bg=r["bg"], fg=FG2,
                     anchor="w").pack(side="left", fill="x", expand=True)
            _btn(r, "↑", lambda i=i: self._move_phase(i,-1)).pack(side="right", padx=1)
            _btn(r, "↓", lambda i=i: self._move_phase(i, 1)).pack(side="right", padx=1)
            _btn(r, "del", lambda i=i: self._remove_phase(i),
                 fg="#aa4444").pack(side="right", padx=4)

    # ════════════════════════════════════════════════════════
    #  CODE GENERATION
    # ════════════════════════════════════════════════════════
    def _generate(self):
        use_ph = self.use_phases.get()
        if use_ph:
            if not self.phases:
                messagebox.showwarning("TauKit", "add at least one phase first"); return
            all_names = set(n for ph in self.phases for n in ph["effects"])
            selected  = [ef for ef in EFFECTS if ef["name"] in all_names]
        else:
            selected = [ef for ef in EFFECTS if self.checks[ef["name"]].get()]

        has_custom_gdi = bool(self._custom_gdis)
        has_custom_bb  = bool(self._custom_bbs)

        if not selected and not has_custom_gdi and not has_custom_bb:
            messagebox.showwarning("TauKit", "select at least one effect"); return

        lines = ["#!/usr/bin/env python3\n# generated by TauKit\n"]

        if self.mb1_enabled.get() or self.mb2_enabled.get():
            lines.append("import sys as _sys\n_u32=__import__('ctypes').windll.user32\n")
        for en, ti, ms in [(self.mb1_enabled, self.mb1_title, self.mb1_msg),
                           (self.mb2_enabled, self.mb2_title, self.mb2_msg)]:
            if en.get():
                t = ti.get().replace('"','\\"'); m = ms.get().replace('"','\\"')
                lines.append(f'if _u32.MessageBoxW(0,"{m}","{t}",0x31)!=1: _sys.exit(0)\n')
        lines.append("\n")
        lines.append(SCRIPT_HEADER)

        extra = set()
        for ef in selected: extra.update(ef.get("deps",[]))
        if has_custom_bb:    extra.add("pyaudio")
        if "math"     in extra: lines.append("import math\n")
        if "colorsys" in extra: lines.append("import colorsys\n")
        for d in sorted(extra):
            if d not in ("math","colorsys","win32gui","win32ui","win32con",
                         "win32api","numpy","pyaudio"):
                lines.append(f"import {d}\n")
        lines.append("\n")

        if use_ph: self._gen_phases(lines, selected)
        else:       self._gen_simple(lines, selected)

        out = self.out_path.get()
        if not out:
            messagebox.showerror("TauKit", "set output path first"); return
        try:
            with open(out, "w", encoding="utf-8") as fp:
                fp.write("".join(lines))
            self._log(f"ok  {out}")
            try: self.gen_status.config(text=f"saved → {os.path.basename(out)}", fg=ACC)
            except: pass
        except Exception as e:
            self._log(f"err {e}"); messagebox.showerror("TauKit", str(e)); return

        if self.do_compile.get():
            threading.Thread(target=self._compile, args=(out,), daemon=True).start()

    def _gen_simple(self, lines, selected):
        audio  = [ef for ef in selected if ef.get("is_audio")]
        visual = [ef for ef in selected if not ef.get("is_audio")]

        # preset visual effects
        for ef in visual:
            lines.append(f"# {ef['name']}\n")
            lines.append(textwrap.dedent(ef["code"])); lines.append("\n")

        # custom GDI blocks
        cg_fns = []
        for i, cg in enumerate(self._custom_gdis):
            fn_name = f"effect_custom_gdi_{i}"
            cg_fns.append(fn_name)
            raw_code = cg["code_widget"].get("1.0", "end-1c")
            sleep_val = cg["sleep"].get().strip() or "0.0"
            indented  = "\n".join("        " + ln for ln in raw_code.splitlines())
            lines.append(f"# custom GDI: {cg['label'].get()}\n")
            lines.append(f"def {fn_name}():\n")
            lines.append(f"    while running:\n")
            lines.append(indented + "\n")
            try:
                sv = float(sleep_val)
                if sv > 0:
                    lines.append(f"        time.sleep({sv})\n")
            except ValueError:
                pass
            lines.append("\n")

        # preset audio
        if audio:
            self._emit_audio_simple(lines, audio)

        # custom bytebeat
        if self._custom_bbs:
            self._emit_custom_bb_simple(lines)

        fns = ([ef["thread"] for ef in visual]
               + cg_fns
               + (["_audio_master"] if audio or self._custom_bbs else []))
        lines.append(f"THREAD_FUNCS=[{','.join(fns)}]\n")
        lines.append("""
threads=[threading.Thread(target=fn,daemon=True) for fn in THREAD_FUNCS]
for t in threads: t.start()
try:
    while True: time.sleep(1)
except KeyboardInterrupt:
    running=False
""")

    def _emit_audio_simple(self, lines, audio):
        lines.append("import pyaudio as _pa\n\n")
        for ef in audio: lines.append(ef["bb_code"])
        lines.append(f"\n_BB={repr([(ef['bb_fn'],ef['bb_rate']) for ef in audio])}\n")
        lines.append("""
def _audio_master():
    g=globals(); fns=[g[n] for n,r in _BB]; rates=[r for n,r in _BB]
    cur=0; rate=rates[0]; CHUNK=2048; sw=rate*12
    p=_pa.PyAudio(); s=p.open(format=_pa.paUInt8,channels=1,rate=rate,output=True); t=0
    while running:
        s.write(bytes(fns[cur](t+i)&0xFF for i in range(CHUNK))); t+=CHUNK
        if len(fns)>1 and t>=sw:
            t=0; cur=(cur+1)%len(fns); nr=rates[cur]
            if nr!=rate:
                s.stop_stream(); s.close(); rate=nr
                s=p.open(format=_pa.paUInt8,channels=1,rate=rate,output=True); sw=rate*12
    s.stop_stream(); s.close(); p.terminate()
\n""")

    def _emit_custom_bb_simple(self, lines):
        """Emit pyaudio block for custom bytebeat formulas (merged with _audio_master if needed)."""
        if not self._custom_bbs: return
        lines.append("import pyaudio as _pa\n\n")
        bb_list = []
        for i, cb in enumerate(self._custom_bbs):
            fn  = f"_bb_custom_{i}"
            try:
                rate = int(cb["rate"].get())
            except ValueError:
                rate = 8000
            formula = cb["formula"].get().strip() or "t"
            lines.append(f"def {fn}(t): return ({formula})&0xFF\n")
            bb_list.append((fn, rate))
        lines.append(f"\n_BB_CUSTOM={repr(bb_list)}\n")
        lines.append("""
def _audio_master():
    g=globals()
    fns=[g[n] for n,r in _BB_CUSTOM]; rates=[r for n,r in _BB_CUSTOM]
    cur=0; rate=rates[0]; CHUNK=2048; sw=rate*12
    p=_pa.PyAudio(); s=p.open(format=_pa.paUInt8,channels=1,rate=rate,output=True); t=0
    while running:
        s.write(bytes(fns[cur](t+i)&0xFF for i in range(CHUNK))); t+=CHUNK
        if len(fns)>1 and t>=sw:
            t=0; cur=(cur+1)%len(fns); nr=rates[cur]
            if nr!=rate:
                s.stop_stream(); s.close(); rate=nr
                s=p.open(format=_pa.paUInt8,channels=1,rate=rate,output=True); sw=rate*12
    s.stop_stream(); s.close(); p.terminate()
\n""")

    def _gen_phases(self, lines, selected):
        audio  = [ef for ef in selected if ef.get("is_audio")]
        visual = [ef for ef in selected if not ef.get("is_audio")]
        ep     = {ef["name"]: [] for ef in selected}
        for i, ph in enumerate(self.phases):
            for n in ph["effects"]:
                if n in ep: ep[n].append(i+1)

        lines.append("phase=1\n\ndef _phase_switcher():\n    global phase\n")
        for i, ph in enumerate(self.phases[:-1]):
            lines.append(f"    time.sleep({ph['duration']}); phase={i+2}\n")
        lines.append(f"    time.sleep({self.phases[-1]['duration']})\n\n")

        for ef in visual:
            ps   = repr(set(ep[ef["name"]]))
            code = textwrap.dedent(ef["code"]).replace(
                "while running:\n",
                f"while running:\n        if phase not in {ps}:\n            time.sleep(0.05); continue\n",1)
            lines.append(f"# {ef['name']} phases:{ep[ef['name']]}\n")
            lines.append(code); lines.append("\n")

        if audio: self._emit_audio_phases(lines, audio, ep)

        fns = [ef["thread"] for ef in visual] + ["_phase_switcher"]
        if audio: fns.append("_audio_master")
        lines.append(f"THREAD_FUNCS=[{','.join(fns)}]\n")
        lines.append("""
threads=[threading.Thread(target=fn,daemon=True) for fn in THREAD_FUNCS]
for t in threads: t.start()
try:
    while True: time.sleep(1)
except KeyboardInterrupt:
    running=False
""")

    def _emit_audio_phases(self, lines, audio, ep):
        lines.append("import pyaudio as _pa\n\n")
        for ef in audio: lines.append(ef["bb_code"])
        pa = {}
        for pi in range(1, len(self.phases)+1):
            for ef in audio:
                if pi in ep.get(ef["name"], []):
                    pa[pi] = (ef["bb_fn"], ef["bb_rate"]); break
        lines.append(f"\n_PA={repr(pa)}\n")
        lines.append("""
def _audio_master():
    CHUNK=2048; p=_pa.PyAudio(); cp=None; s=None; rate=8000; t=0
    while running:
        if phase not in _PA:
            if s: s.stop_stream(); s.close(); s=None
            time.sleep(0.05); cp=phase; continue
        if phase!=cp:
            if s: s.stop_stream(); s.close()
            fn,rate=_PA[phase]; s=p.open(format=_pa.paUInt8,channels=1,rate=rate,output=True)
            cp=phase; t=0
        fn=globals()[_PA[phase][0]]
        s.write(bytes(fn(t+i)&0xFF for i in range(CHUNK))); t+=CHUNK
    if s: s.stop_stream(); s.close()
    p.terminate()
\n""")

    def _compile(self, path):
        self._log("pyinstaller starting...")
        cmd = [sys.executable, "-m", "PyInstaller"]
        if self.onefile.get():   cmd.append("--onefile")
        if self.noconsole.get(): cmd.append("--noconsole")
        ico = self.icon_path.get().strip()
        if ico and os.path.exists(ico): cmd += ["--icon", ico]
        cmd.append(path)
        try:
            cwd  = os.path.dirname(os.path.abspath(path))
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, text=True, cwd=cwd)
            for line in proc.stdout:
                line = line.rstrip()
                if line: self.after(0, self._log, line)
            proc.wait()
            if proc.returncode == 0:
                dist = os.path.join(os.path.dirname(path), "dist")
                self.after(0, self._log, f"done  exe in {dist}")
                self.after(0, lambda: messagebox.showinfo("TauKit", f"exe in:\n{dist}"))
            else:
                self.after(0, self._log, f"pyinstaller error code {proc.returncode}")
        except FileNotFoundError:
            self.after(0, self._log, "pyinstaller not found  ->  pip install pyinstaller")
        except Exception as e:
            self.after(0, self._log, f"error: {e}")


# ════════════════════════════════════════════════════════════
if __name__ == "__main__":
    app = TauKit()
    app.mainloop()
